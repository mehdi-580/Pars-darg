CAR IMAGE SLOTS

All car image slots are intentionally empty in this version.
Add your own images here using these names:

pars_elx.png     -> Peugeot Pars ELX
405.png          -> Peugeot 405
samand.png       -> Samand LX
pride.png        -> Saipa Pride
l90.png          -> Renault L90

PNG, WEBP, JPG/JPEG and SVG are supported.
If an image is missing, the game shows an empty placeholder instead of a generated car.

TUNE IMAGES (TUNE tab: Shoti / Remove bumper)

Shoti (pickup):
pars-shote.png   -> Peugeot Pars ELX
405-shote.png    -> Peugeot 405
samand-shote.png -> Samand LX
pride-shote.png  -> Saipa Pride

Shoti + bumper removed:
pars-sh-sp.png   -> Peugeot Pars ELX
405-sh-sp.png    -> Peugeot 405
samand-sh-sp.png -> Samand LX
pride-sh-sp.png  -> Saipa Pride
l90-sh-sp.png    -> Renault L90

Bumper removed only:
pars-sp.png      -> Peugeot Pars ELX
405-sp.png       -> Peugeot 405
samand-sp.png    -> Samand LX
pride-sp.png     -> Saipa Pride

If a tune image is missing, the normal car image is shown instead.
