# Pars Drag - Vorix Studio

Garage/race project for Godot 4.x.

## Car images
All four car image slots are intentionally empty. Add your own images to `assets/`:
- `pars_elx.png`
- `405.png`
- `samand.png`
- `pride.png`

PNG, WEBP, JPG/JPEG and SVG are supported. Missing images remain blank placeholders.
