extends Control
## Garage screen: car preview + collapsible engine/gearbox shops.

var money_label: Label
var gift_edit: LineEdit
var stats_label: Label
var rows: Dictionary = {}
var b201: Button
var b402: Button
var flip_btn: Button
var sound_btn: Button
var car_buttons: Dictionary = {}
var engine_buttons: Array[Button] = []
var gearbox_buttons: Array[Button] = []
var engine_panel: Control
var gearbox_panel: Control
var engine_tab: Button
var gearbox_tab: Button
var tune_panel: Control
var tune_tab: Button
var shoti_btn: Button
var bumper_btn: Button
var tune_hint: Label
var car_view: TextureRect
var preview_texture: TextureRect
var preview_title: Label
var preview_info: Label
var preview_action: Button
var preview_car_id: String = ""

func _label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l

func _button(text: String, size: int) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", size)
	b.custom_minimum_size = Vector2(0, 64)
	return b

func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.09, 0.10, 0.13)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 36)
	margin.add_theme_constant_override("margin_right", 36)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)

	var top := HBoxContainer.new()
	vbox.add_child(top)
	var title := _label("PARS DRAG  •  VORIX STUDIO", 32, Color(1, 0.85, 0.3))
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(title)
	var money_box := VBoxContainer.new()
	money_box.add_theme_constant_override("separation", 2)
	top.add_child(money_box)
	money_label = _label("", 30, Color(0.5, 1.0, 0.5))
	money_box.add_child(money_label)

	# Gift code, right under the money.
	var gift_row := HBoxContainer.new()
	gift_row.alignment = BoxContainer.ALIGNMENT_END
	gift_row.add_theme_constant_override("separation", 6)
	money_box.add_child(gift_row)
	gift_edit = LineEdit.new()
	gift_edit.placeholder_text = "Gift code"
	gift_edit.max_length = 20
	gift_edit.custom_minimum_size = Vector2(170, 44)
	gift_edit.add_theme_font_size_override("font_size", 20)
	gift_edit.text_submitted.connect(_on_gift_submit)
	gift_row.add_child(gift_edit)
	var gift_btn := _button("GIFT", 20)
	gift_btn.custom_minimum_size = Vector2(90, 44)
	gift_btn.pressed.connect(_on_gift)
	gift_row.add_child(gift_btn)
	var top_race := _button("RACE ▶", 25)
	top_race.custom_minimum_size = Vector2(190, 64)
	top_race.modulate = Color(0.55, 1.0, 0.55)
	top_race.pressed.connect(_on_race)
	top.add_child(top_race)
	var highway_btn := _button("HIGHWAY 🛣", 25)
	highway_btn.name = "HighwayButton"
	highway_btn.custom_minimum_size = Vector2(220, 64)
	highway_btn.modulate = Color(1.0, 0.72, 0.25)
	highway_btn.pressed.connect(_on_highway)
	top.add_child(highway_btn)

	# ---------- car showroom / preview ----------
	var showroom := VBoxContainer.new()
	showroom.add_theme_constant_override("separation", 5)
	vbox.add_child(showroom)
	showroom.add_child(_label("CAR SHOWROOM  •  Tap a car to preview it before buying", 19, Color(0.75, 0.85, 1.0)))

	var car_scroll := ScrollContainer.new()
	car_scroll.name = "CarPurchaseScroll"
	car_scroll.custom_minimum_size = Vector2(0, 64)
	car_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	car_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	showroom.add_child(car_scroll)
	var car_row := HBoxContainer.new()
	car_row.add_theme_constant_override("separation", 7)
	car_scroll.add_child(car_row)
	for car in Game.CARS:
		var cb := _button("", 17)
		cb.custom_minimum_size = Vector2(210, 56)
		cb.pressed.connect(_preview_car.bind(str(car["id"])))
		car_row.add_child(cb)
		car_buttons[str(car["id"])] = cb

	var preview_panel := PanelContainer.new()
	preview_panel.custom_minimum_size = Vector2(0, 125)
	showroom.add_child(preview_panel)
	var preview_box := HBoxContainer.new()
	preview_box.add_theme_constant_override("separation", 18)
	preview_panel.add_child(preview_box)

	preview_texture = TextureRect.new()
	preview_texture.custom_minimum_size = Vector2(260, 110)
	preview_texture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview_texture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	preview_box.add_child(preview_texture)

	var preview_text_box := VBoxContainer.new()
	preview_text_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_box.add_child(preview_text_box)
	preview_title = _label("", 28, Color.WHITE)
	preview_text_box.add_child(preview_title)
	preview_info = _label("", 18, Color(0.8, 0.85, 0.92))
	preview_info.size_flags_vertical = Control.SIZE_EXPAND_FILL
	preview_text_box.add_child(preview_info)
	preview_action = _button("", 22)
	preview_action.custom_minimum_size = Vector2(240, 62)
	preview_action.pressed.connect(_buy_preview_car)
	preview_text_box.add_child(preview_action)

	# ---------- middle ----------
	var mid := HBoxContainer.new()
	mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
	mid.add_theme_constant_override("separation", 20)
	vbox.add_child(mid)

	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mid.add_child(left)

	car_view = TextureRect.new()
	car_view.size_flags_vertical = Control.SIZE_EXPAND_FILL
	car_view.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	car_view.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	car_view.flip_h = Game.flip_car
	car_view.texture = Game.get_car_texture()
	car_view.modulate = Game.current_car_data()["tint"]
	left.add_child(car_view)
	if car_view.texture == null:
		var hint := _label("CAR IMAGE PLACEHOLDER\nAdd your car image to res://assets/", 20, Color(0.45, 0.55, 0.65))
		hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		hint.size_flags_vertical = Control.SIZE_EXPAND_FILL
		hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		left.add_child(hint)

	stats_label = _label("", 20, Color(0.85, 0.9, 1.0))
	left.add_child(stats_label)

	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(470, 0)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 6)
	mid.add_child(right)

	# Fixed tabs; the shop itself scrolls so mobile never loses the RACE controls.
	var shop_tabs := HBoxContainer.new()
	shop_tabs.add_theme_constant_override("separation", 6)
	shop_tabs.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	right.add_child(shop_tabs)
	engine_tab = _button("ENGINE", 22)
	gearbox_tab = _button("GEARBOX", 22)
	tune_tab = _button("TUNE", 22)
	engine_tab.custom_minimum_size = Vector2(0, 58)
	gearbox_tab.custom_minimum_size = Vector2(0, 58)
	tune_tab.custom_minimum_size = Vector2(0, 58)
	engine_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gearbox_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tune_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	engine_tab.pressed.connect(_show_engine)
	gearbox_tab.pressed.connect(_show_gearbox)
	tune_tab.pressed.connect(_show_tune)
	shop_tabs.add_child(engine_tab)
	shop_tabs.add_child(gearbox_tab)
	shop_tabs.add_child(tune_tab)

	var shop_scroll := ScrollContainer.new()
	shop_scroll.name = "ShopScroll"
	shop_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	shop_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	shop_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	right.add_child(shop_scroll)

	var shop_content := VBoxContainer.new()
	shop_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	shop_content.add_theme_constant_override("separation", 5)
	shop_scroll.add_child(shop_content)

	engine_panel = _make_shop_panel(Game.ENGINES, true)
	gearbox_panel = _make_shop_panel(Game.GEARBOXES, false)
	shop_content.add_child(engine_panel)
	shop_content.add_child(gearbox_panel)

	# TUNE tab: shoti (pickup) + bumper removal for the selected car.
	tune_panel = VBoxContainer.new()
	tune_panel.add_theme_constant_override("separation", 5)
	shoti_btn = Button.new()
	shoti_btn.custom_minimum_size = Vector2(0, 67)
	shoti_btn.add_theme_font_size_override("font_size", 20)
	shoti_btn.pressed.connect(_on_shoti)
	tune_panel.add_child(shoti_btn)
	bumper_btn = Button.new()
	bumper_btn.custom_minimum_size = Vector2(0, 67)
	bumper_btn.add_theme_font_size_override("font_size", 20)
	bumper_btn.pressed.connect(_on_bumper)
	tune_panel.add_child(bumper_btn)
	tune_hint = _label("", 15, Color(0.7, 0.7, 0.75))
	tune_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tune_hint.custom_minimum_size = Vector2(0, 40)
	tune_panel.add_child(tune_hint)
	shop_content.add_child(tune_panel)

	shop_content.add_child(_label("OTHER UPGRADES", 19, Color(0.75, 0.85, 1.0)))
	for u in Game.UPGRADES:
		_add_row(shop_content, u)

	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 10)
	vbox.add_child(bottom)
	b201 = _button("201 m", 22)
	b201.custom_minimum_size = Vector2(115, 58)
	b201.pressed.connect(_on_distance.bind(201))
	bottom.add_child(b201)
	b402 = _button("402 m", 22)
	b402.custom_minimum_size = Vector2(115, 58)
	b402.pressed.connect(_on_distance.bind(402))
	bottom.add_child(b402)
	flip_btn = _button("Flip car", 20)
	flip_btn.pressed.connect(_on_flip)
	bottom.add_child(flip_btn)
	sound_btn = _button("", 20)
	sound_btn.pressed.connect(_on_sound)
	bottom.add_child(sound_btn)

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_child(spacer)
	var race_btn := _button("RACE ▶", 30)
	race_btn.custom_minimum_size = Vector2(260, 78)
	race_btn.modulate = Color(0.55, 1.0, 0.55)
	race_btn.pressed.connect(_on_race)
	bottom.add_child(race_btn)

	var studio := _label("VORIX STUDIO", 17, Color(0.45, 0.55, 0.7))
	studio.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(studio)

	_preview_car(Game.current_car)
	_show_engine()
	_refresh()

func _make_shop_panel(items: Array, is_engine: bool) -> VBoxContainer:
	var panel := VBoxContainer.new()
	panel.add_theme_constant_override("separation", 5)
	for i in range(items.size()):
		var item: Dictionary = items[i]
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 67)
		b.add_theme_font_size_override("font_size", 16)
		if is_engine:
			b.pressed.connect(_on_engine.bind(i))
			engine_buttons.append(b)
		else:
			b.pressed.connect(_on_gearbox.bind(i))
			gearbox_buttons.append(b)
		panel.add_child(b)
	return panel

func _add_row(parent: Control, u: Dictionary) -> void:
	var id: String = u["id"]
	var panel := PanelContainer.new()
	parent.add_child(panel)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	panel.add_child(h)
	var names := VBoxContainer.new()
	names.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	names.add_child(_label(u["name"], 22, Color.WHITE))
	names.add_child(_label(u["desc"], 15, Color(0.7, 0.7, 0.75)))
	h.add_child(names)
	var lvl := _label("", 21, Color(1, 0.85, 0.3))
	lvl.custom_minimum_size = Vector2(80, 0)
	lvl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(lvl)
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(170, 56)
	btn.add_theme_font_size_override("font_size", 21)
	btn.pressed.connect(_on_buy.bind(id))
	h.add_child(btn)
	rows[id] = {"lvl": lvl, "btn": btn}

func _show_engine() -> void:
	if engine_panel == null:
		return
	engine_panel.visible = true
	gearbox_panel.visible = false
	tune_panel.visible = false
	engine_tab.modulate = Color(0.55, 1.0, 0.55)
	gearbox_tab.modulate = Color.WHITE
	tune_tab.modulate = Color.WHITE

func _show_gearbox() -> void:
	if gearbox_panel == null:
		return
	engine_panel.visible = false
	gearbox_panel.visible = true
	tune_panel.visible = false
	engine_tab.modulate = Color.WHITE
	gearbox_tab.modulate = Color(0.55, 1.0, 0.55)
	tune_tab.modulate = Color.WHITE

func _show_tune() -> void:
	if tune_panel == null:
		return
	engine_panel.visible = false
	gearbox_panel.visible = false
	tune_panel.visible = true
	engine_tab.modulate = Color.WHITE
	gearbox_tab.modulate = Color.WHITE
	tune_tab.modulate = Color(0.55, 1.0, 0.55)

func _preview_car(id: String) -> void:
	preview_car_id = id
	var car: Dictionary = Game.car_data(id)
	preview_title.text = str(car["name"])
	var owned := Game.is_car_owned(id)
	var price := int(car["price"])
	preview_info.text = "Preview before purchase\nWeight class: %.0f%%\nTorque: x%.2f   Grip: x%.2f\n\n" % [float(car["mass"]) * 100.0, float(car["torque"]), float(car["mu"])]
	var tex := Game.get_car_texture_for(id)
	preview_texture.texture = tex
	preview_texture.flip_h = Game.flip_car
	if tex == null:
		preview_info.text += "Add your own image at res://assets/%s.png" % str(car["asset"])
	if Game.current_car == id:
		preview_action.text = "SELECTED"
		preview_action.disabled = true
	elif owned:
		preview_action.text = "SELECT %s" % str(car["name"])
		preview_action.disabled = false
	else:
		preview_action.text = "BUY  $%d" % price
		preview_action.disabled = Game.money < price

func _buy_preview_car() -> void:
	if preview_car_id != "" and Game.buy_car(preview_car_id):
		_preview_car(preview_car_id)
		_refresh()

func _refresh() -> void:
	money_label.text = "$ %d   •   %s" % [Game.money, Game.car_name()]
	for car in Game.CARS:
		var id: String = str(car["id"])
		var cb: Button = car_buttons[id]
		if Game.current_car == id:
			cb.text = "✓ %s" % car["name"]
		else:
			cb.text = ("OWNED  " if Game.is_car_owned(id) else "PREVIEW  ") + str(car["name"])
		cb.disabled = false

	for i in range(Game.ENGINES.size()):
		var e: Dictionary = Game.ENGINES[i]
		var owned_or_selected: bool = Game.owned_engines.has(i)
		var selected: bool = i == Game.selected_engine
		var can_buy: bool = Game.money >= int(e["price"])
		engine_buttons[i].text = (("✓ " if selected else "SELECT ") if owned_or_selected else "BUY ") + "%s  • $%d\nTorque %d Nm | %d hp | %d rpm | %.2f m³" % [e["name"], int(e["price"]), int(e["torque"]), int(e["hp"]), int(e["rpm"]), float(e["space"])]
		engine_buttons[i].disabled = selected or (not owned_or_selected and not can_buy)
		engine_buttons[i].modulate = Color(0.55, 1.0, 0.55) if selected else Color.WHITE

	for i in range(Game.GEARBOXES.size()):
		var g: Dictionary = Game.GEARBOXES[i]
		var owned_or_selected: bool = Game.owned_gearboxes.has(i)
		var selected: bool = i == Game.selected_gearbox
		var can_buy: bool = Game.money >= int(g["price"])
		gearbox_buttons[i].text = (("✓ " if selected else "SELECT ") if owned_or_selected else "BUY ") + "%s  • $%d\nShift %.2fs | %d gears | Accel x%.2f | %.2f m³" % [g["name"], int(g["price"]), float(g["shift"]), int(g["gears"]), float(g["accel"]), float(g["space"])]
		gearbox_buttons[i].disabled = selected or (not owned_or_selected and not can_buy)
		gearbox_buttons[i].modulate = Color(0.55, 1.0, 0.55) if selected else Color.WHITE

	# Tune tab + main car picture follow the selected car's tuning.
	var cid: String = Game.current_car
	var sh_on: bool = Game.is_shoti(cid)
	var nb_on: bool = Game.is_no_bumper(cid)
	shoti_btn.text = "SHOTI (pickup)  •  " + ("ON" if sh_on else "OFF")
	shoti_btn.modulate = Color(0.55, 1.0, 0.55) if sh_on else Color.WHITE
	bumper_btn.text = "REMOVE BUMPER  •  " + ("ON" if nb_on else "OFF")
	bumper_btn.modulate = Color(0.55, 1.0, 0.55) if nb_on else Color.WHITE
	var tuned_name: String = Game.tune_asset_name(cid)
	if tuned_name == "":
		tune_hint.text = "%s: stock look" % Game.car_name()
	elif Game.find_asset(tuned_name) == "":
		tune_hint.text = "Missing picture: res://assets/%s.png\nShowing the normal car until it is added." % tuned_name
	else:
		tune_hint.text = "%s: using %s" % [Game.car_name(), tuned_name]
	car_view.texture = Game.get_car_texture()

	for u in Game.UPGRADES:
		var id: String = u["id"]
		var lv: int = Game.levels[id]
		var row: Dictionary = rows[id]
		var lvl_label: Label = row["lvl"]
		var btn: Button = row["btn"]
		lvl_label.text = "Lv %d/%d" % [lv, Game.MAX_LEVEL]
		if lv >= Game.MAX_LEVEL:
			btn.text = "MAX"
			btn.disabled = true
		else:
			var cost: int = Game.upgrade_cost(id)
			btn.text = "Buy  $%d" % cost
			btn.disabled = Game.money < cost

	var st: Dictionary = Game.build_stats()
	var res: Dictionary = Game.simulate(st, float(Game.distance))
	var key: String = str(Game.distance)
	var b: float = Game.best[key]
	var best_txt: String = "--" if b <= 0.0 else "%.2f s" % b
	var eng: Dictionary = Game.selected_engine_data()
	var gb: Dictionary = Game.selected_gearbox_data()
	stats_label.text = "%s • %s\nTorque %d Nm | %d hp | %d rpm | %.2f m³ engine\nGearbox: %.2fs shift | %d gears | Accel x%.2f | %.2f m³\nWeight %d kg | 0-100 ~%.1f s | %d m ~%.1f s\nWins %d / %d    Best %d m: %s" % [eng["name"], gb["name"], int(eng["torque"]), int(eng["hp"]), int(eng["rpm"]), float(eng["space"]), float(gb["shift"]), int(gb["gears"]), float(gb["accel"]), float(gb["space"]), int(st["mass"]), float(res["t100"]), Game.distance, float(res["et"]), Game.wins, Game.races, Game.distance, best_txt]
	b201.modulate = Color(0.5, 1, 0.5) if Game.distance == 201 else Color.WHITE
	b402.modulate = Color(0.5, 1, 0.5) if Game.distance == 402 else Color.WHITE
	flip_btn.text = "Flip car: ON" if Game.flip_car else "Flip car: OFF"
	sound_btn.text = "Sound: ON" if Game.sound_on else "Sound: OFF"
	_preview_car(preview_car_id if preview_car_id != "" else Game.current_car)

func _on_gift_submit(_text: String) -> void:
	_on_gift()

func _on_gift() -> void:
	var result: int = Game.redeem_code(gift_edit.text)
	gift_edit.clear()
	gift_edit.release_focus()
	if result > 0:
		gift_edit.placeholder_text = "+$%d" % result
	elif result < 0:
		gift_edit.placeholder_text = "Already used"
	else:
		gift_edit.placeholder_text = "Invalid code"
	_refresh()

func _on_shoti() -> void:
	Game.set_tune(Game.current_car, "shoti", not Game.is_shoti(Game.current_car))
	_refresh()

func _on_bumper() -> void:
	Game.set_tune(Game.current_car, "no_bumper", not Game.is_no_bumper(Game.current_car))
	_refresh()

func _on_buy(id: String) -> void:
	Game.buy(id)
	_refresh()

func _on_car(id: String) -> void:
	_preview_car(id)

func _on_engine(index: int) -> void:
	if Game.buy_engine(index):
		_refresh()

func _on_gearbox(index: int) -> void:
	if Game.buy_gearbox(index):
		_refresh()

func _on_distance(d: int) -> void:
	Game.distance = d
	Game.save_game()
	_refresh()

func _on_flip() -> void:
	Game.flip_car = not Game.flip_car
	Game.save_game()
	get_tree().reload_current_scene()

func _on_sound() -> void:
	Game.sound_on = not Game.sound_on
	Game.save_game()
	_refresh()

func _on_race() -> void:
	get_tree().change_scene_to_file("res://scenes/race.tscn")

func _on_highway() -> void:
	if ResourceLoader.exists("res://scenes/highway.tscn"):
		get_tree().change_scene_to_file("res://scenes/highway.tscn")
