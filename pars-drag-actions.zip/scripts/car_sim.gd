extends RefCounted
## Simple drag-car physics: gearbox, torque curve, traction limit, drag, nitro.

const R := 0.29            # tyre radius (m)
const FINAL := 4.06        # final drive
const IDLE := 900.0
var REDLINE: float = 6300.0
const G := 9.81
const CDA := 0.66          # drag coefficient * frontal area
const RHO := 1.2
const CRR := 0.015
const DRIVE_EFF := 0.88

var ratios: Array[float] = [3.417, 1.95, 1.357, 1.054, 0.854]

var torque_peak: float = 160.0
var mass: float = 1150.0
var mu: float = 0.85
var shift_time: float = 0.36
var nitro_time: float = 0.0
var nitro_boost: float = 0.3

var x: float = 0.0          # front bumper position (m)
var v: float = 0.0          # speed (m/s)
var gear: int = 1
var rpm: float = IDLE
var shift_timer: float = 0.0
var nitro_left: float = 0.0
var nitro_active: bool = false
var wheelspin: bool = false
var braking: bool = false
var top_speed: float = 0.0


func setup(s: Dictionary) -> void:
	torque_peak = s["torque"]
	mass = s["mass"]
	mu = s["mu"]
	shift_time = s["shift_time"]
	if s.has("ratios"):
		var new_ratios: Array[float] = []
		for value in s["ratios"]:
			new_ratios.append(float(value))
		ratios = new_ratios
	if s.has("redline"):
		REDLINE = float(s["redline"])
	nitro_time = s["nitro_time"]
	nitro_boost = s["nitro_boost"]
	nitro_left = nitro_time


func torque_curve(r: float) -> float:
	if r < 4200.0:
		return lerpf(0.62, 1.0, clampf((r - 1000.0) / 3200.0, 0.0, 1.0))
	return lerpf(1.0, 0.74, clampf((r - 4200.0) / 2100.0, 0.0, 1.0))


## Returns "" (could not shift), "early", "good" or "perfect".
func try_shift(clutch_pressed: bool = true) -> String:
	if not clutch_pressed:
		return "clutch"
	if gear >= ratios.size() or shift_timer > 0.0:
		return ""
	var quality := "early"
	if rpm >= 5600.0:
		quality = "perfect"
	elif rpm >= 4800.0:
		quality = "good"
	gear += 1
	shift_timer = shift_time
	return quality


func step(dt: float, throttle: bool, use_nitro: bool) -> void:
	var ratio: float = ratios[gear - 1] * FINAL
	var rpm_wheels: float = v / R * 9.5493 * ratio
	var target: float = maxf(rpm_wheels, IDLE)
	if throttle and gear == 1 and v < 8.0:
		target = maxf(target, 3400.0)   # clutch slip on launch
	shift_timer = maxf(0.0, shift_timer - dt)

	var drive: float = 0.0
	nitro_active = false
	if throttle and shift_timer <= 0.0 and rpm < REDLINE and not braking:
		drive = torque_peak * torque_curve(rpm) * ratio * DRIVE_EFF / R
		if use_nitro and nitro_left > 0.0:
			drive *= 1.0 + nitro_boost
			nitro_left = maxf(0.0, nitro_left - dt)
			nitro_active = true

	var limit: float = mu * mass * G * 0.62     # front-wheel-drive traction
	wheelspin = drive > limit
	if wheelspin:
		drive = limit * 0.93
		target = maxf(target, rpm_wheels + 900.0)
	target = minf(target, REDLINE + 200.0)
	rpm = lerpf(rpm, target, clampf(dt * 10.0, 0.0, 1.0))

	var resist: float = 0.5 * RHO * CDA * v * v + CRR * mass * G
	if not throttle:
		resist += 300.0
	if braking:
		resist += mass * 7.0
	v = maxf(0.0, v + (drive - resist) / mass * dt)
	x += v * dt
	top_speed = maxf(top_speed, v)
