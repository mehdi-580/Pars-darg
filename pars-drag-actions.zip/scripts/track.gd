extends Node2D
## Draws the drag strip (sky skyline, grass, wall, asphalt, lines, finish).

const PPM := 36.0
var dist_m: float = 402.0
var fnt: Font = ThemeDB.fallback_font


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	var cam := get_viewport().get_camera_2d()
	var cx: float = 0.0
	if cam != null:
		cx = cam.get_screen_center_position().x
	var vw: float = get_viewport_rect().size.x
	var left: float = cx - vw * 0.5 - 300.0
	var right: float = cx + vw * 0.5 + 300.0
	var width: float = right - left

	# far skyline (parallax)
	var par: float = 0.6
	var i0: int = int(floor((left - cx * par) / 140.0))
	var i1: int = int(ceil((right - cx * par) / 140.0))
	for i in range(i0, i1 + 1):
		var hgt: float = 70.0 + 110.0 * absf(sin(float(i) * 12.9898))
		var wx: float = float(i) * 140.0 + cx * par
		draw_rect(Rect2(wx, 250.0 - hgt, 110.0, hgt), Color(0.45, 0.55, 0.68))

	# grass
	draw_rect(Rect2(left, 250.0, width, 90.0), Color(0.27, 0.5, 0.27))

	# light poles
	var p0: int = int(floor(left / 540.0))
	var p1: int = int(ceil(right / 540.0))
	for i in range(p0, p1 + 1):
		var px: float = float(i) * 540.0
		draw_rect(Rect2(px - 3.0, 190.0, 6.0, 150.0), Color(0.2, 0.2, 0.22))
		draw_rect(Rect2(px - 18.0, 184.0, 36.0, 10.0), Color(1.0, 0.95, 0.7))

	# wall (red/white blocks)
	var w0: int = int(floor(left / 120.0))
	var w1: int = int(ceil(right / 120.0))
	for i in range(w0, w1 + 1):
		var col: Color = Color(0.9, 0.9, 0.92) if i % 2 == 0 else Color(0.8, 0.15, 0.15)
		draw_rect(Rect2(float(i) * 120.0, 335.0, 120.0, 40.0), col)

	# asphalt
	draw_rect(Rect2(left, 375.0, width, 210.0), Color(0.21, 0.21, 0.23))

	# dashed lane line
	var d0: int = int(floor(left / 100.0))
	var d1: int = int(ceil(right / 100.0))
	for i in range(d0, d1 + 1):
		draw_rect(Rect2(float(i) * 100.0, 470.0, 60.0, 4.0), Color(1, 1, 1, 0.65))

	# bottom curb + foreground
	for i in range(w0, w1 + 1):
		var col2: Color = Color(0.9, 0.9, 0.92) if i % 2 == 0 else Color(0.8, 0.15, 0.15)
		draw_rect(Rect2(float(i) * 120.0, 585.0, 120.0, 14.0), col2)
	draw_rect(Rect2(left, 599.0, width, 1500.0), Color(0.33, 0.33, 0.36))

	# start line
	draw_rect(Rect2(-4.0, 375.0, 8.0, 210.0), Color(1, 1, 1, 0.9))
	_text("START", Vector2(0.0, 320.0), 26)

	# distance markers
	var step: int = 50 if dist_m < 300.0 else 100
	var m: int = step
	while float(m) < dist_m:
		var mx: float = float(m) * PPM
		draw_rect(Rect2(mx - 2.0, 375.0, 4.0, 210.0), Color(1, 1, 1, 0.25))
		_text("%d m" % m, Vector2(mx, 320.0), 26)
		m += step

	# finish line + gantry
	var fx: float = dist_m * PPM
	for row in range(21):
		for c in range(2):
			var dark: bool = (row + c) % 2 == 0
			draw_rect(Rect2(fx + float(c) * 10.0 - 10.0, 375.0 + float(row) * 10.0, 10.0, 10.0),
				Color(0.05, 0.05, 0.05) if dark else Color(0.95, 0.95, 0.95))
	draw_rect(Rect2(fx - 130.0, 214.0, 6.0, 122.0), Color(0.2, 0.2, 0.22))
	draw_rect(Rect2(fx + 124.0, 214.0, 6.0, 122.0), Color(0.2, 0.2, 0.22))
	draw_rect(Rect2(fx - 130.0, 214.0, 260.0, 46.0), Color(0.1, 0.1, 0.12))
	_text("FINISH", Vector2(fx, 247.0), 32)


func _text(t: String, center: Vector2, size: int) -> void:
	draw_string(fnt, Vector2(center.x - 150.0, center.y), t, HORIZONTAL_ALIGNMENT_CENTER, 300.0, size, Color(1, 1, 1, 0.9))
