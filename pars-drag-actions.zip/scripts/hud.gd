extends Control
## Race HUD: tachometer, touch buttons (multi-touch), start lights, result panel.

signal gas_changed(pressed: bool)
signal clutch_changed(pressed: bool)
signal nitro_changed(pressed: bool)
signal shift_pressed
signal retry_pressed
signal garage_pressed

# ---- values filled in by race.gd every frame ----
var rpm: float = 900.0
var speed_kmh: float = 0.0
var gear: int = 1
var nitro_frac: float = 0.0
var has_nitro: bool = false
var nitro_active: bool = false
var wheelspin: bool = false
var clock: float = 0.0
var reaction: float = -1.0
var ambers: int = 0
var green: bool = false
var red_foul: bool = false
var prog_player: float = 0.0
var prog_opp: float = 0.0
var gap_m: float = 0.0
var banner: String = ""
var hint: String = ""
var flash_text: String = ""
var flash_t: float = 0.0
var flash_color: Color = Color.WHITE
var showing_result: bool = false
var result: Dictionary = {}

var pointers: Dictionary = {}     # touch index -> action name
var fnt: Font = ThemeDB.fallback_font


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)


func flash(t: String, c: Color) -> void:
	flash_text = t
	flash_color = c
	flash_t = 0.9


func show_result(r: Dictionary) -> void:
	result = r
	showing_result = true
	# release everything that is held
	pointers.clear()
	gas_changed.emit(false)
	clutch_changed.emit(false)
	nitro_changed.emit(false)


func _process(delta: float) -> void:
	flash_t = maxf(0.0, flash_t - delta)
	queue_redraw()


# ---------------------------------------------------------------- layout
func _sz() -> Vector2:
	return get_viewport_rect().size


func _circle_btn(action: String) -> Dictionary:
	var s := _sz()
	match action:
		"gas":
			return {"c": Vector2(s.x - 150.0, s.y - 150.0), "r": 115.0}
		"shift":
			return {"c": Vector2(150.0, s.y - 150.0), "r": 100.0}
		"clutch":
			return {"c": Vector2(345.0, s.y - 220.0), "r": 72.0}
		"nitro":
			return {"c": Vector2(345.0, s.y - 105.0), "r": 72.0}
		"back":
			return {"c": Vector2(s.x - 45.0, 45.0), "r": 30.0}
	return {"c": Vector2.ZERO, "r": 0.0}


func _result_rect(action: String) -> Rect2:
	var s := _sz()
	if action == "retry":
		return Rect2(s.x * 0.5 - 290.0, s.y * 0.5 + 130.0, 270.0, 80.0)
	return Rect2(s.x * 0.5 + 20.0, s.y * 0.5 + 130.0, 270.0, 80.0)


func _hit(pos: Vector2) -> String:
	if showing_result:
		if _result_rect("retry").has_point(pos):
			return "retry"
		if _result_rect("garage").has_point(pos):
			return "garage"
		return ""
	for a in ["gas", "clutch", "shift", "nitro", "back"]:
		var b: Dictionary = _circle_btn(a)
		var c: Vector2 = b["c"]
		var r: float = b["r"]
		if pos.distance_to(c) <= r * 1.15:
			return a
	return ""


# ---------------------------------------------------------------- input
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = make_input_local(event) as InputEventScreenTouch
		_pointer(t.index, t.pressed, t.position)
	elif event is InputEventMouseButton:
		# Touches are already handled above (they also produce emulated mouse events).
		if event.device == InputEvent.DEVICE_ID_EMULATION:
			return
		var m: InputEventMouseButton = make_input_local(event) as InputEventMouseButton
		if m.button_index == MOUSE_BUTTON_LEFT:
			_pointer(-1, m.pressed, m.position)


func _pointer(idx: int, pressed: bool, pos: Vector2) -> void:
	if pressed:
		var a: String = _hit(pos)
		if a != "":
			pointers[idx] = a
			_apply(a, true)
	elif pointers.has(idx):
		var a2: String = pointers[idx]
		pointers.erase(idx)
		_apply(a2, false)


func _apply(a: String, pressed: bool) -> void:
	match a:
		"gas":
			gas_changed.emit(pressed)
		"clutch":
			clutch_changed.emit(pressed)
		"nitro":
			nitro_changed.emit(pressed)
		"shift":
			if pressed:
				shift_pressed.emit()
		"retry":
			if pressed:
				retry_pressed.emit()
		"garage", "back":
			if pressed:
				garage_pressed.emit()


func _is_down(a: String) -> bool:
	return pointers.values().has(a)


# ---------------------------------------------------------------- drawing
func _text(t: String, center: Vector2, size: int, color: Color) -> void:
	draw_string(fnt, Vector2(center.x - 400.0, center.y + float(size) * 0.35), t,
		HORIZONTAL_ALIGNMENT_CENTER, 800.0, size, color)


func _text_left(t: String, pos: Vector2, size: int, color: Color) -> void:
	draw_string(fnt, pos, t, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size, color)


func _draw() -> void:
	var s := _sz()
	_draw_top(s)
	_draw_gauge(s)
	_draw_buttons(s)

	if banner != "":
		_text(banner, Vector2(s.x * 0.5, 215.0), 64, Color(1, 1, 1, 0.95))
	if hint != "":
		_text(hint, Vector2(s.x * 0.5, 275.0), 26, Color(1, 0.9, 0.5, 0.95))
	if flash_t > 0.0:
		var c: Color = flash_color
		c.a = clampf(flash_t * 2.0, 0.0, 1.0)
		_text(flash_text, Vector2(s.x * 0.5, 345.0), 46, c)

	if showing_result:
		_draw_result(s)


func _draw_top(s: Vector2) -> void:
	# progress bar
	var bx: float = s.x * 0.5 - 250.0
	draw_rect(Rect2(bx, 22.0, 500.0, 8.0), Color(0, 0, 0, 0.5))
	draw_rect(Rect2(bx + 496.0, 12.0, 4.0, 28.0), Color.WHITE)
	draw_circle(Vector2(bx + 500.0 * clampf(prog_opp, 0.0, 1.0), 26.0), 9.0, Color(1.0, 0.35, 0.3))
	draw_circle(Vector2(bx + 500.0 * clampf(prog_player, 0.0, 1.0), 26.0), 9.0, Color(0.3, 0.65, 1.0))

	# start lights
	var tc := Vector2(s.x * 0.5, 82.0)
	draw_rect(Rect2(tc.x - 105.0, tc.y - 30.0, 210.0, 60.0), Color(0.04, 0.04, 0.05, 0.9))
	for i in range(3):
		var lit: bool = ambers > i and not green
		var col: Color = Color(1.0, 0.75, 0.1) if lit else Color(0.28, 0.22, 0.05)
		if red_foul:
			col = Color(1.0, 0.1, 0.1)
		draw_circle(Vector2(tc.x - 66.0 + float(i) * 44.0, tc.y), 15.0, col)
	var gcol: Color = Color(0.2, 1.0, 0.35) if green else Color(0.05, 0.2, 0.08)
	if red_foul:
		gcol = Color(1.0, 0.1, 0.1)
	draw_circle(Vector2(tc.x + 72.0, tc.y), 15.0, gcol)

	# ET / speed panel
	draw_rect(Rect2(14.0, 14.0, 270.0, 116.0), Color(0.02, 0.03, 0.05, 0.72))
	_text_left("VORIX STUDIO", Vector2(28.0, 34.0), 16, Color(0.55, 0.75, 1.0))
	_text_left("ET  %.3f" % clock, Vector2(28.0, 58.0), 38, Color.WHITE)
	_text_left("%d km/h" % int(speed_kmh), Vector2(28.0, 96.0), 28, Color(0.8, 0.9, 1.0))
	if reaction >= 0.0:
		_text_left("RT  %.3f" % reaction, Vector2(28.0, 122.0), 20, Color(1.0, 0.9, 0.5))

	# gap
	if gap_m != 0.0:
		var ahead: bool = gap_m > 0.0
		var t: String = "AHEAD %.1f m" % absf(gap_m) if ahead else "BEHIND %.1f m" % absf(gap_m)
		_text(t, Vector2(s.x * 0.5, 138.0), 22, Color(0.5, 1.0, 0.5) if ahead else Color(1.0, 0.5, 0.45))

	# back button
	var bb: Dictionary = _circle_btn("back")
	var bc: Vector2 = bb["c"]
	draw_circle(bc, 30.0, Color(0, 0, 0, 0.45))
	_text("X", bc, 26, Color(1, 1, 1, 0.8))


func _draw_gauge(s: Vector2) -> void:
	var gc := Vector2(s.x * 0.5, s.y - 135.0)
	var a0: float = PI * 0.75
	var sweep: float = PI * 1.5
	draw_circle(gc, 128.0, Color(0, 0, 0, 0.55))
	draw_arc(gc, 114.0, a0, a0 + sweep, 48, Color(1, 1, 1, 0.45), 4.0)
	draw_arc(gc, 114.0, a0 + sweep * (6000.0 / 7000.0), a0 + sweep, 12, Color(1.0, 0.2, 0.2), 8.0)
	for i in range(8):
		var a: float = a0 + sweep * float(i) / 7.0
		draw_line(gc + Vector2.from_angle(a) * 98.0, gc + Vector2.from_angle(a) * 114.0, Color(1, 1, 1, 0.8), 3.0)
		_text(str(i), gc + Vector2.from_angle(a) * 80.0, 18, Color(1, 1, 1, 0.8))

	# shift light ring
	if gear < 5 and rpm >= 5600.0:
		var ring: Color = Color(0.2, 1.0, 0.3) if rpm < 6250.0 else Color(1.0, 0.2, 0.2)
		draw_arc(gc, 126.0, 0.0, TAU, 48, ring, 6.0)

	var f: float = clampf(rpm / 7000.0, 0.0, 1.0)
	var na: float = a0 + sweep * f
	draw_line(gc, gc + Vector2.from_angle(na) * 106.0, Color(1.0, 0.45, 0.2), 5.0)
	draw_circle(gc, 34.0, Color(0.08, 0.08, 0.1))
	_text(str(gear), gc, 40, Color(1.0, 0.9, 0.3))


func _draw_buttons(s: Vector2) -> void:
	# GAS
	var g: Dictionary = _circle_btn("gas")
	var gc: Vector2 = g["c"]
	var gr: float = g["r"]
	var gdown: bool = _is_down("gas")
	draw_circle(gc, gr, Color(0.2, 0.8, 0.3, 0.75 if gdown else 0.4))
	draw_arc(gc, gr, 0.0, TAU, 48, Color(1, 1, 1, 0.7), 5.0)
	_text("GAS", gc, 44, Color.WHITE)
	if wheelspin:
		_text("WHEELSPIN", gc + Vector2(0.0, -gr - 20.0), 20, Color(1.0, 0.8, 0.3))

	# SHIFT
	var sh: Dictionary = _circle_btn("shift")
	var sc: Vector2 = sh["c"]
	var sr: float = sh["r"]
	var sdown: bool = _is_down("shift")
	var glow: bool = gear < 5 and rpm >= 5600.0 and rpm < 6250.0
	var scol: Color = Color(0.2, 0.9, 0.3, 0.7) if glow else Color(0.3, 0.5, 1.0, 0.75 if sdown else 0.4)
	draw_circle(sc, sr, scol)
	draw_arc(sc, sr, 0.0, TAU, 48, Color(1, 1, 1, 0.7), 5.0)
	_text("SHIFT", sc, 36, Color.WHITE)

	# CLUTCH: hold this while pressing SHIFT.
	var cl: Dictionary = _circle_btn("clutch")
	var cc: Vector2 = cl["c"]
	var cr: float = cl["r"]
	var cdown: bool = _is_down("clutch")
	var ccol: Color = Color(1.0, 0.65, 0.2, 0.8 if cdown else 0.42)
	draw_circle(cc, cr, ccol)
	draw_arc(cc, cr, 0.0, TAU, 48, Color(1, 1, 1, 0.7), 4.0)
	_text("CLUTCH", cc, 24, Color.WHITE)

	# NITRO
	var n: Dictionary = _circle_btn("nitro")
	var nc: Vector2 = n["c"]
	var nr: float = n["r"]
	var ndown: bool = _is_down("nitro")
	var ncol: Color = Color(0.1, 0.8, 1.0, 0.75 if (ndown or nitro_active) else 0.35)
	if not has_nitro:
		ncol = Color(0.4, 0.4, 0.4, 0.3)
	draw_circle(nc, nr, ncol)
	draw_arc(nc, nr, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 3.0)
	if has_nitro and nitro_frac > 0.0:
		draw_arc(nc, nr + 7.0, -PI * 0.5, -PI * 0.5 + TAU * nitro_frac, 40, Color(0.3, 0.9, 1.0), 7.0)
	_text("NITRO" if has_nitro else "NO NITRO", nc, 22, Color.WHITE)


func _draw_result(s: Vector2) -> void:
	draw_rect(Rect2(0.0, 0.0, s.x, s.y), Color(0, 0, 0, 0.6))
	var pr := Rect2(s.x * 0.5 - 330.0, s.y * 0.5 - 250.0, 660.0, 470.0)
	draw_rect(pr, Color(0.1, 0.11, 0.15, 0.97))
	draw_rect(pr, Color(1, 1, 1, 0.3), false, 3.0)
	var title: String = result.get("title", "")
	var tcol: Color = result.get("color", Color.WHITE)
	_text(title, Vector2(s.x * 0.5, s.y * 0.5 - 200.0), 56, tcol)
	var lines: Array = result.get("lines", [])
	var y: float = s.y * 0.5 - 130.0
	for l in lines:
		_text(str(l), Vector2(s.x * 0.5, y), 28, Color(0.92, 0.94, 1.0))
		y += 40.0
	for a in ["retry", "garage"]:
		var r: Rect2 = _result_rect(a)
		draw_rect(r, Color(0.2, 0.7, 0.3) if a == "retry" else Color(0.25, 0.4, 0.9))
		draw_rect(r, Color(1, 1, 1, 0.6), false, 3.0)
		_text("RETRY" if a == "retry" else "GARAGE", r.get_center(), 34, Color.WHITE)
