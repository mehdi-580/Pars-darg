extends Node
## Autoload "Game": save data, upgrades, stats.

const CarSim := preload("res://scripts/car_sim.gd")
const SAVE_PATH := "user://pars_drag_save.json"
const MAX_LEVEL := 5

# Five selectable engines. Prices rise faster than power so the expensive
# engines are a real progression choice rather than automatic purchases.
const ENGINES := [
	{"id":"e1", "name":"1.6 Stock", "price":0, "torque":150.0, "hp":105.0, "rpm":5800.0, "space":0.42, "mass":135.0},
	{"id":"e2", "name":"1.8 Sport", "price":2200, "torque":178.0, "hp":132.0, "rpm":6200.0, "space":0.46, "mass":148.0},
	{"id":"e3", "name":"2.0 Turbo", "price":6200, "torque":245.0, "hp":205.0, "rpm":6500.0, "space":0.50, "mass":165.0},
	{"id":"e4", "name":"2.2 Turbo", "price":14500, "torque":320.0, "hp":285.0, "rpm":6800.0, "space":0.56, "mass":182.0},
	{"id":"e5", "name":"2.5 Racing", "price":32000, "torque":410.0, "hp":380.0, "rpm":7200.0, "space":0.63, "mass":205.0}
]

# Five selectable gearboxes. Shift time, gear count and acceleration effect
# are shown in the garage; each gearbox also has its own ratios.
const GEARBOXES := [
	{"id":"g1", "name":"5-Speed Street", "price":0, "shift":0.36, "gears":5, "accel":1.00, "space":0.34, "ratios":[3.417,1.950,1.357,1.054,0.854]},
	{"id":"g2", "name":"5-Speed Sport", "price":1800, "shift":0.29, "gears":5, "accel":1.04, "space":0.36, "ratios":[3.600,2.050,1.430,1.100,0.880]},
	{"id":"g3", "name":"6-Speed Close", "price":5200, "shift":0.24, "gears":6, "accel":1.09, "space":0.39, "ratios":[3.550,2.150,1.550,1.200,0.960,0.780]},
	{"id":"g4", "name":"6-Speed Racing", "price":12000, "shift":0.18, "gears":6, "accel":1.15, "space":0.42, "ratios":[3.700,2.250,1.650,1.280,1.020,0.820]},
	{"id":"g5", "name":"7-Speed Pro", "price":26000, "shift":0.13, "gears":7, "accel":1.22, "space":0.46, "ratios":[3.800,2.400,1.750,1.400,1.120,0.900,0.740]}
]

# Cars available in the showroom. Each car keeps its own identity while
# upgrades remain shared for a simple career-style progression.
const CARS := [
	# Peugeot Pars ELX is the original starter car; its picture is restored.
	{"id": "pars_elx", "name": "Peugeot Pars ELX", "asset": "pars_elx", "price": 0, "torque": 1.00, "mass": 1.00, "mu": 1.00, "tint": Color.WHITE},
	{"id": "peugeot_405", "name": "Peugeot 405", "asset": "405", "price": 3500, "torque": 1.10, "mass": 1.00, "mu": 1.02, "tint": Color.WHITE},
	{"id": "samand_lx", "name": "Samand LX", "asset": "samand", "price": 5500, "torque": 1.16, "mass": 1.04, "mu": 1.03, "tint": Color.WHITE},
	{"id": "saipa_pride", "name": "Saipa Pride", "asset": "pride", "price": 2500, "torque": 0.90, "mass": 0.92, "mu": 0.98, "tint": Color.WHITE},
	{"id": "renault_l90", "name": "Renault L90", "asset": "l90", "price": 7000, "torque": 1.08, "mass": 0.98, "mu": 1.01, "tint": Color.WHITE}
]

# Vertical tweak (pixels) for the car picture, if its wheels float or sink.
const CAR_Y_ADJUST := 4.0

const UPGRADES := [
	{"id": "turbo", "name": "Turbo", "desc": "+10% torque per level", "base": 650},
	{"id": "tires", "name": "Tires", "desc": "More grip, less wheelspin", "base": 300},
	{"id": "nitro", "name": "Nitro", "desc": "Longer and stronger boost", "base": 500},
	{"id": "weight", "name": "Weight reduction", "desc": "-30 kg per level", "base": 250},
]

## Gift codes: code -> money reward. Each code can be used once per save.
const GIFT_CODES := {"5050": 600000}

var money: int = 500
var redeemed_codes: Array = []
var levels: Dictionary = {"turbo": 0, "tires": 0, "nitro": 0, "weight": 0}
var selected_engine: int = 0
var selected_gearbox: int = 0
var owned_engines: Array = [0]
var owned_gearboxes: Array = [0]
var wins: int = 0
var races: int = 0
var best: Dictionary = {"201": 0.0, "402": 0.0}
var distance: int = 402
var flip_car: bool = false
var sound_on: bool = true
var owned_cars: Array = ["pars_elx"]
var current_car: String = "pars_elx"

# Tune pictures per car (put them in res://assets/):
#   <prefix>-shote.png   shoti (pickup) version
#   <prefix>-sh-sp.png   shoti + bumper removed
#   <prefix>-sp.png      bumper removed only
# If a tune picture is missing, the normal car picture is shown instead.
const TUNE_PREFIX := {"pars_elx": "pars", "peugeot_405": "405", "samand_lx": "samand", "saipa_pride": "pride", "renault_l90": "l90"}
# car id -> {"shoti": bool, "no_bumper": bool}
var tune: Dictionary = {}


func _ready() -> void:
	load_game()


# ---------- car picture ----------
func current_car_data() -> Dictionary:
	for c in CARS:
		if c["id"] == current_car:
			return c
	return CARS[0]


func car_data(id: String) -> Dictionary:
	for c in CARS:
		if c["id"] == id:
			return c
	return CARS[0]

func get_car_texture_for(id: String) -> Texture2D:
	# Car slots are intentionally empty until the player supplies the real images.
	# Put an image in res://assets/ using the car asset name (png/webp/jpg/jpeg/svg)
	# and it will automatically appear in the preview and race.
	var car: Dictionary = car_data(id)
	var asset_name: String = str(car.get("asset", ""))
	if asset_name.is_empty():
		return null
	# Tuned look (shoti / no bumper) first; falls back to the normal picture if missing.
	var tuned_path: String = find_asset(tune_asset_name(id))
	if tuned_path != "":
		return load(tuned_path) as Texture2D
	var image_path: String = find_asset(asset_name)
	if image_path != "":
		return load(image_path) as Texture2D
	return null


## Returns the res:// path of assets/<name>.(png|webp|jpg|jpeg|svg), or "" if none exists.
func find_asset(asset_name: String) -> String:
	if asset_name.is_empty():
		return ""
	for ext in ["png", "webp", "jpg", "jpeg", "svg"]:
		var image_path: String = "res://assets/" + asset_name + "." + ext
		if ResourceLoader.exists(image_path):
			return image_path
	return ""


# ---------- tuning (shoti / bumper) ----------
func is_shoti(id: String) -> bool:
	return bool(tune.get(id, {}).get("shoti", false))


func is_no_bumper(id: String) -> bool:
	return bool(tune.get(id, {}).get("no_bumper", false))


func set_tune(id: String, key: String, on: bool) -> void:
	var t: Dictionary = tune.get(id, {"shoti": false, "no_bumper": false})
	t[key] = on
	tune[id] = t
	save_game()


## Asset name of the tuned picture for this car ("" = stock look).
func tune_asset_name(id: String) -> String:
	var prefix: String = str(TUNE_PREFIX.get(id, car_data(id).get("asset", "")))
	var sh: bool = is_shoti(id)
	var nb: bool = is_no_bumper(id)
	if sh and nb:
		return prefix + "-sh-sp"
	if sh:
		return prefix + "-shote"
	if nb:
		return prefix + "-sp"
	return ""

func car_name(id: String = current_car) -> String:
	for c in CARS:
		if c["id"] == id:
			return c["name"]
	return CARS[0]["name"]


func car_price(id: String) -> int:
	for c in CARS:
		if c["id"] == id:
			return int(c["price"])
	return 0


func is_car_owned(id: String) -> bool:
	return owned_cars.has(id)


func buy_car(id: String) -> bool:
	if is_car_owned(id):
		current_car = id
		save_game()
		return true
	var price := car_price(id)
	if price <= 0 or money < price:
		return false
	money -= price
	owned_cars.append(id)
	current_car = id
	save_game()
	return true


func get_car_texture() -> Texture2D:
	return get_car_texture_for(current_car)


# ---------- upgrades ----------
func upgrade_cost(id: String) -> int:
	var base: int = 0
	for u in UPGRADES:
		if u["id"] == id:
			base = u["base"]
	var lv: int = levels[id]
	return int(float(base) * pow(1.8, float(lv)))


func buy(id: String) -> bool:
	var lv: int = levels[id]
	if lv >= MAX_LEVEL:
		return false
	var cost: int = upgrade_cost(id)
	if money < cost:
		return false
	money -= cost
	levels[id] = lv + 1
	save_game()
	return true


func total_levels() -> int:
	var t: int = 0
	for k in levels:
		var l: int = levels[k]
		t += l
	return t


func selected_engine_data() -> Dictionary:
	return ENGINES[clampi(selected_engine, 0, ENGINES.size() - 1)]

func selected_gearbox_data() -> Dictionary:
	return GEARBOXES[clampi(selected_gearbox, 0, GEARBOXES.size() - 1)]

func buy_engine(index: int) -> bool:
	if index < 0 or index >= ENGINES.size():
		return false
	var price := int(ENGINES[index]["price"])
	if owned_engines.has(index):
		selected_engine = index
		save_game()
		return true
	if price > money:
		return false
	money -= price
	owned_engines.append(index)
	selected_engine = index
	save_game()
	return true

func buy_gearbox(index: int) -> bool:
	if index < 0 or index >= GEARBOXES.size():
		return false
	var price := int(GEARBOXES[index]["price"])
	if owned_gearboxes.has(index):
		selected_gearbox = index
		save_game()
		return true
	if price > money:
		return false
	money -= price
	owned_gearboxes.append(index)
	selected_gearbox = index
	save_game()
	return true

func build_stats() -> Dictionary:
	var t: int = levels["turbo"]
	var ti: int = levels["tires"]
	var n: int = levels["nitro"]
	var w: int = levels["weight"]
	var car: Dictionary = current_car_data()
	var eng: Dictionary = selected_engine_data()
	var gb: Dictionary = selected_gearbox_data()
	var torque: float = float(eng["torque"]) * float(car["torque"]) * (1.0 + 0.10 * t) * float(gb["accel"])
	return {
		"torque": torque,
		"mass": (1150.0 * float(car["mass"])) + float(eng["mass"]) - 135.0 - 30.0 * w,
		"mu": (0.85 + 0.08 * ti) * float(car["mu"]),
		"shift_time": float(gb["shift"]),
		"gear_count": int(gb["gears"]),
		"ratios": gb["ratios"],
		"redline": float(eng["rpm"]),
		"engine_hp": float(eng["hp"]) * float(car["torque"]) * (1.0 + 0.10 * t),
		"engine_space": float(eng["space"]),
		"gearbox_space": float(gb["space"]),
		"nitro_time": 1.2 * n,
		"nitro_boost": (0.30 + 0.04 * n) if n > 0 else 0.0,
	}


func opponent_stats(tier: int) -> Dictionary:
	return {
		"torque": 160.0 * (1.0 + 0.05 * tier),
		"mass": 1150.0 - 5.0 * tier,
		"mu": minf(0.85 + 0.014 * tier, 1.25),
		"shift_time": maxf(0.36 - 0.008 * tier, 0.15),
		"nitro_time": 0.0 if tier < 8 else 1.5 + 0.05 * (tier - 8),
		"nitro_boost": 0.32,
	}


func peak_hp(st: Dictionary) -> float:
	var sim := CarSim.new()
	sim.setup(st)
	var best_kw: float = 0.0
	for r in range(1000, int(st.get("redline", 6300.0)) + 1, 100):
		var rr: float = float(r)
		best_kw = maxf(best_kw, sim.torque_peak * sim.torque_curve(rr) * rr / 9549.0)
	return best_kw * 1.341


## Perfect-driver estimate used for the garage stats.
func simulate(st: Dictionary, dist: float) -> Dictionary:
	var sim := CarSim.new()
	sim.setup(st)
	var t: float = 0.0
	var t100: float = 0.0
	while sim.x < dist and t < 60.0:
		if sim.rpm > 5900.0:
			sim.try_shift()
		sim.step(0.01, true, sim.x > 40.0)
		t += 0.01
		if t100 == 0.0 and sim.v >= 27.78:
			t100 = t
	return {"et": t, "t100": t100}


# ---------- gift codes ----------
## Returns the money reward on success, 0 if the code is invalid, -1 if already used.
func redeem_code(code: String) -> int:
	var c: String = code.strip_edges()
	if not GIFT_CODES.has(c):
		return 0
	if redeemed_codes.has(c):
		return -1
	var reward: int = int(GIFT_CODES[c])
	money += reward
	redeemed_codes.append(c)
	save_game()
	return reward


# ---------- save / load ----------
func save_game() -> void:
	var data := {
		"money": money, "levels": levels, "wins": wins, "races": races,
		"best": best, "distance": distance, "flip_car": flip_car, "sound_on": sound_on,
		"owned_cars": owned_cars, "current_car": current_car,
		"selected_engine": selected_engine, "selected_gearbox": selected_gearbox,
		"owned_engines": owned_engines, "owned_gearboxes": owned_gearboxes,
		"redeemed_codes": redeemed_codes, "tune": tune,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(data))


func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var d: Variant = JSON.parse_string(f.get_as_text())
	if typeof(d) != TYPE_DICTIONARY:
		return
	money = int(d.get("money", money))
	wins = int(d.get("wins", 0))
	races = int(d.get("races", 0))
	distance = int(d.get("distance", 402))
	var rc: Variant = d.get("redeemed_codes", [])
	if typeof(rc) == TYPE_ARRAY:
		redeemed_codes = []
		for c in rc:
			if typeof(c) == TYPE_STRING and not redeemed_codes.has(c):
				redeemed_codes.append(c)
	var tn: Variant = d.get("tune", {})
	if typeof(tn) == TYPE_DICTIONARY:
		tune = {}
		for k in tn:
			var v: Variant = tn[k]
			if typeof(v) == TYPE_DICTIONARY:
				tune[str(k)] = {"shoti": bool(v.get("shoti", false)), "no_bumper": bool(v.get("no_bumper", false))}
	flip_car = bool(d.get("flip_car", false))
	sound_on = bool(d.get("sound_on", true))
	var oc: Variant = d.get("owned_cars", ["pars_elx"])
	if typeof(oc) == TYPE_ARRAY:
		owned_cars = ["pars_elx"]
		for id in oc:
			if typeof(id) == TYPE_STRING and car_price(id) >= 0 and not owned_cars.has(id):
				owned_cars.append(id)
	owned_engines = [0]
	var oe: Variant = d.get("owned_engines", [0])
	if typeof(oe) == TYPE_ARRAY:
		for i in oe:
			if typeof(i) == TYPE_INT and i >= 0 and i < ENGINES.size() and not owned_engines.has(i):
				owned_engines.append(i)
	owned_gearboxes = [0]
	var og: Variant = d.get("owned_gearboxes", [0])
	if typeof(og) == TYPE_ARRAY:
		for i in og:
			if typeof(i) == TYPE_INT and i >= 0 and i < GEARBOXES.size() and not owned_gearboxes.has(i):
				owned_gearboxes.append(i)
	selected_engine = clampi(int(d.get("selected_engine", 0)), 0, ENGINES.size() - 1)
	selected_gearbox = clampi(int(d.get("selected_gearbox", 0)), 0, GEARBOXES.size() - 1)
	if not owned_engines.has(selected_engine): selected_engine = 0
	if not owned_gearboxes.has(selected_gearbox): selected_gearbox = 0
	current_car = str(d.get("current_car", "pars_elx"))
	if not is_car_owned(current_car):
		current_car = "pars_elx"
	var lv: Variant = d.get("levels", {})
	if typeof(lv) == TYPE_DICTIONARY:
		for k in levels:
			levels[k] = clampi(int(lv.get(k, 0)), 0, MAX_LEVEL)
	var b: Variant = d.get("best", {})
	if typeof(b) == TYPE_DICTIONARY:
		best["201"] = float(b.get("201", 0.0))
		best["402"] = float(b.get("402", 0.0))
