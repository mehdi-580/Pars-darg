extends Node2D
## Drag race: start lights, launch, manual shifting, nitro, AI opponent, results.

const CarSim := preload("res://scripts/car_sim.gd")
const TrackScript := preload("res://scripts/track.gd")
const HudScript := preload("res://scripts/hud.gd")

const PPM := 36.0            # pixels per meter
const CAR_LEN_M := 4.5       # picture is scaled to this length
const LANE_Y_OPP := 425.0
const LANE_Y_PLAYER := 520.0
const MIX_RATE := 22050.0

enum State { INTRO, TREE, RUN, DONE }

var state: int = State.INTRO
var dist: float = 402.0
var player: CarSim = CarSim.new()
var opp: CarSim = CarSim.new()
var opp_tier: int = 0
var opp_shift_rpm: Array[float] = []
var opp_rt: float = 0.25
var opp_launched: bool = false

var t_state: float = 0.0
var green_at: float = 2.1
var race_clock: float = 0.0
var touch_gas: bool = false
var touch_clutch: bool = false
var touch_nitro: bool = false
var gas_held: bool = false
var nitro_held: bool = false
var launched: bool = false
var reaction: float = -1.0
var player_t: float = -1.0
var opp_t: float = -1.0
var player_trap: float = 0.0
var winner: String = ""
var end_timer: float = 0.0
var foul: bool = false

var cam: Camera2D
var track: TrackScript
var hud: HudScript
var player_car: Node2D
var opp_car: Node2D
var smoke: CPUParticles2D
var flame: CPUParticles2D

var audio_player: AudioStreamPlayer
var playback: AudioStreamGeneratorPlayback
var phase: float = 0.0
var lp: float = 0.0


func _ready() -> void:
	dist = float(Game.distance)

	# sky
	var bg_layer := CanvasLayer.new()
	bg_layer.layer = -10
	add_child(bg_layer)
	var sky := ColorRect.new()
	sky.color = Color(0.55, 0.76, 0.95)
	sky.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg_layer.add_child(sky)

	track = TrackScript.new()
	track.dist_m = dist
	add_child(track)

	# opponent + player cars
	opp_tier = clampi(Game.total_levels() + randi_range(-3, 3), 0, 30)
	opp.setup(Game.opponent_stats(opp_tier))
	player.setup(Game.build_stats())
	for i in range(4):
		opp_shift_rpm.append(randf_range(5400.0, 6200.0))
	opp_rt = randf_range(0.16, 0.40)

	var tints: Array[Color] = [Color(1.0, 0.55, 0.55), Color(0.6, 0.75, 1.0), Color(0.7, 1.0, 0.7),
		Color(1.0, 0.9, 0.5), Color(0.85, 0.7, 1.0)]
	opp_car = _make_car(tints[randi() % tints.size()], 1.18)
	player_car = _make_car(Game.current_car_data()["tint"], 1.28)
	add_child(opp_car)
	add_child(player_car)
	_add_particles()

	cam = Camera2D.new()
	add_child(cam)
	cam.make_current()

	# HUD
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	hud = HudScript.new()
	layer.add_child(hud)
	var studio := Label.new()
	studio.text = "VORIX STUDIO"
	studio.position = Vector2(18, 132)
	studio.add_theme_font_size_override("font_size", 18)
	studio.add_theme_color_override("font_color", Color(0.65, 0.75, 0.9, 0.9))
	layer.add_child(studio)
	hud.has_nitro = player.nitro_time > 0.0
	hud.gas_changed.connect(_on_gas)
	hud.clutch_changed.connect(_on_clutch)
	hud.nitro_changed.connect(_on_nitro)
	hud.shift_pressed.connect(_on_shift)
	hud.retry_pressed.connect(_on_retry)
	hud.garage_pressed.connect(_on_garage)

	_setup_audio()
	_update_visuals(0.0)


# ------------------------------------------------------------ building
func _make_car(tint: Color, scale_mul: float) -> Node2D:
	var root := Node2D.new()
	root.scale = Vector2(scale_mul, scale_mul)

	# shadow
	var shadow := Polygon2D.new()
	var pts := PackedVector2Array()
	for i in range(24):
		var a: float = TAU * float(i) / 24.0
		pts.append(Vector2(cos(a) * CAR_LEN_M * PPM * 0.5, sin(a) * 8.0))
	shadow.polygon = pts
	shadow.color = Color(0, 0, 0, 0.35)
	root.add_child(shadow)

	var tex: Texture2D = Game.get_car_texture()
	if tex != null:
		var spr := Sprite2D.new()
		spr.texture = tex
		spr.centered = false
		var s: float = (CAR_LEN_M * PPM) / float(tex.get_width())
		spr.scale = Vector2(s, s)
		spr.offset = Vector2(-float(tex.get_width()) * 0.5, -float(tex.get_height()))
		spr.position = Vector2(0.0, Game.CAR_Y_ADJUST)
		spr.flip_h = Game.flip_car
		spr.modulate = tint
		root.add_child(spr)
	else:
		# Placeholder box shown only while assets/pars_elx.png is missing.
		var box := Polygon2D.new()
		var w: float = CAR_LEN_M * PPM * 0.5
		box.polygon = PackedVector2Array([Vector2(-w, -44.0), Vector2(w, -44.0), Vector2(w, 0.0), Vector2(-w, 0.0)])
		box.color = tint * Color(0.6, 0.6, 0.6, 1.0)
		root.add_child(box)
		var lab := Label.new()
		lab.text = "add the car picture in res://assets/" + str(Game.current_car_data().get("asset", "pars_elx")) + ".png"
		lab.position = Vector2(-w + 6.0, -40.0)
		lab.add_theme_font_size_override("font_size", 16)
		root.add_child(lab)
	return root


func _add_particles() -> void:
	smoke = CPUParticles2D.new()
	smoke.position = Vector2(-CAR_LEN_M * PPM * 0.33, -10.0)
	smoke.emitting = false
	smoke.amount = 30
	smoke.lifetime = 0.9
	smoke.local_coords = false
	smoke.direction = Vector2(-1.0, -0.25)
	smoke.spread = 25.0
	smoke.gravity = Vector2.ZERO
	smoke.initial_velocity_min = 40.0
	smoke.initial_velocity_max = 110.0
	smoke.scale_amount_min = 5.0
	smoke.scale_amount_max = 12.0
	var sg := Gradient.new()
	sg.set_color(0, Color(0.9, 0.9, 0.9, 0.6))
	sg.set_color(1, Color(0.9, 0.9, 0.9, 0.0))
	smoke.color_ramp = sg
	player_car.add_child(smoke)

	flame = CPUParticles2D.new()
	flame.position = Vector2(-CAR_LEN_M * PPM * 0.5, -20.0)
	flame.emitting = false
	flame.amount = 24
	flame.lifetime = 0.25
	flame.direction = Vector2(-1.0, 0.0)
	flame.spread = 8.0
	flame.gravity = Vector2.ZERO
	flame.initial_velocity_min = 150.0
	flame.initial_velocity_max = 260.0
	flame.scale_amount_min = 4.0
	flame.scale_amount_max = 9.0
	var fg := Gradient.new()
	fg.set_color(0, Color(0.5, 0.85, 1.0, 1.0))
	fg.set_color(1, Color(1.0, 0.4, 0.1, 0.0))
	flame.color_ramp = fg
	player_car.add_child(flame)


func _setup_audio() -> void:
	if not Game.sound_on:
		return
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = MIX_RATE
	gen.buffer_length = 0.12
	audio_player = AudioStreamPlayer.new()
	audio_player.stream = gen
	audio_player.volume_db = -8.0
	add_child(audio_player)
	audio_player.play()
	playback = audio_player.get_stream_playback() as AudioStreamGeneratorPlayback


func _fill_audio(engine_rpm: float, power: float) -> void:
	if playback == null:
		return
	var n: int = playback.get_frames_available()
	var inc: float = (engine_rpm / 60.0 * 2.0) / MIX_RATE   # 4 cylinders, 4-stroke
	var vol: float = 0.30 + 0.45 * power
	for _i in range(n):
		phase += inc
		if phase >= 1.0:
			phase -= 1.0
		var smp: float = (phase * 2.0 - 1.0) * 0.55 + sin(phase * TAU * 2.0) * 0.25 + (randf() * 2.0 - 1.0) * 0.06
		lp += (smp - lp) * 0.22
		playback.push_frame(Vector2(lp * vol, lp * vol))


# ------------------------------------------------------------ input
func _on_gas(p: bool) -> void:
	touch_gas = p


func _on_clutch(p: bool) -> void:
	touch_clutch = p


func _on_nitro(p: bool) -> void:
	touch_nitro = p


func _on_shift() -> void:
	if state != State.RUN or not launched:
		return
	var q: String = player.try_shift(touch_clutch or Input.is_key_pressed(KEY_C))
	match q:
		"clutch":
			hud.flash("HOLD CLUTCH!", Color(1.0, 0.65, 0.25))
		"perfect":
			hud.flash("PERFECT SHIFT!", Color(0.3, 1.0, 0.4))
		"good":
			hud.flash("Good", Color(1.0, 0.9, 0.3))
		"early":
			hud.flash("Too early", Color(1.0, 0.5, 0.4))


func _input(event: InputEvent) -> void:
	# keyboard (for testing on PC): Space = gas, C = clutch, Up/Shift = shift, N = nitro
	var k := event as InputEventKey
	if k != null and k.pressed and not k.echo:
		if k.keycode == KEY_UP or k.keycode == KEY_SHIFT:
			_on_shift()


func _on_retry() -> void:
	get_tree().reload_current_scene()


func _on_garage() -> void:
	get_tree().change_scene_to_file("res://scenes/garage.tscn")


# ------------------------------------------------------------ main loop
func _process(delta: float) -> void:
	delta = minf(delta, 0.033)
	gas_held = touch_gas or Input.is_key_pressed(KEY_SPACE)
	var clutch_held: bool = touch_clutch or Input.is_key_pressed(KEY_C)
	nitro_held = touch_nitro or Input.is_key_pressed(KEY_N)
	hud.banner = ""
	hud.hint = ""

	match state:
		State.INTRO:
			t_state += delta
			hud.hint = "Get ready..."
			if gas_held:
				hud.hint = "Take your finger off GAS!"
			elif t_state > 1.5:
				state = State.TREE
				t_state = 0.0
				green_at = 2.1 + randf_range(0.0, 0.4)
		State.TREE:
			t_state += delta
			hud.hint = "Wait for green - then hold GAS!"
			if t_state < 0.6:
				hud.ambers = 0
			else:
				hud.ambers = clampi(int((t_state - 0.6) / 0.5) + 1, 0, 3)
			if gas_held:
				_false_start()
			elif t_state >= green_at:
				state = State.RUN
				race_clock = 0.0
				hud.green = true
		State.RUN:
			_race_step(delta)
		State.DONE:
			if not foul:
				_physics(delta)

	_update_visuals(delta)
	_update_hud()
	_fill_audio(player.rpm, 1.0 if (gas_held and launched) else 0.2)


func _race_step(delta: float) -> void:
	race_clock += delta
	if race_clock < 1.2:
		hud.banner = "GO!"
	if not launched:
		hud.hint = "HOLD GAS!"
		if gas_held:
			launched = true
			reaction = race_clock
	_physics(delta)

	if winner != "":
		end_timer += delta
		if end_timer > 1.6:
			_show_result()


func _physics(delta: float) -> void:
	var throttle: bool = launched and gas_held
	player.step(delta, throttle, nitro_held and launched)

	if not opp_launched and race_clock >= opp_rt:
		opp_launched = true
	if opp_launched:
		var gi: int = opp.gear - 1
		if gi < opp_shift_rpm.size() and opp.rpm >= opp_shift_rpm[gi]:
			opp.try_shift()
		opp.step(delta, true, opp.nitro_time > 0.0 and opp.x > dist * 0.25)
	else:
		opp.step(delta, false, false)

	if player_t < 0.0 and player.x >= dist:
		player_t = race_clock - (player.x - dist) / maxf(player.v, 1.0)
		player_trap = player.v * 3.6
		player.braking = true
		if winner == "":
			winner = "player"
			end_timer = 0.0
	if opp_t < 0.0 and opp.x >= dist:
		opp_t = race_clock - (opp.x - dist) / maxf(opp.v, 1.0)
		opp.braking = true
		if winner == "":
			winner = "opp"
			end_timer = 0.0


# ------------------------------------------------------------ results
func _false_start() -> void:
	foul = true
	state = State.DONE
	Game.races += 1
	Game.save_game()
	hud.red_foul = true
	hud.show_result({
		"title": "FALSE START!",
		"color": Color(1.0, 0.3, 0.3),
		"lines": ["You pressed GAS before the green light.", "Disqualified - no reward.", "Wait for the green light!"],
	})


func _show_result() -> void:
	state = State.DONE
	var won: bool = winner == "player"
	var factor: float = 1.0 if dist >= 400.0 else 0.6
	var reward: int = 0
	if won:
		reward = int(float(250 + opp_tier * 55) * factor)
	else:
		reward = int(60.0 * factor)
	Game.money += reward
	Game.races += 1
	if won:
		Game.wins += 1

	var lines: Array[String] = []
	var record: bool = false
	if player_t > 0.0 and reaction >= 0.0:
		var et: float = player_t - reaction
		lines.append("Your ET: %.3f s   (RT %.3f)" % [et, reaction])
		lines.append("Trap speed: %d km/h" % int(player_trap))
		var key: String = str(Game.distance)
		var b: float = Game.best[key]
		if b <= 0.0 or et < b:
			Game.best[key] = et
			record = true
	else:
		lines.append("You did not finish the run.")
	if opp_t > 0.0:
		lines.append("Opponent ET: %.3f s" % (opp_t - opp_rt))
	else:
		lines.append("Opponent: not finished")
	lines.append("Reward: +$%d" % reward)
	if record:
		lines.append("NEW PERSONAL BEST!")
	Game.save_game()

	hud.show_result({
		"title": "YOU WIN!" if won else "YOU LOSE",
		"color": Color(0.3, 1.0, 0.4) if won else Color(1.0, 0.4, 0.35),
		"lines": lines,
	})


# ------------------------------------------------------------ visuals
func _update_visuals(_delta: float) -> void:
	var px: float = (player.x - CAR_LEN_M * 0.5) * PPM
	var ox: float = (opp.x - CAR_LEN_M * 0.5) * PPM
	player_car.position = Vector2(px, LANE_Y_PLAYER)
	opp_car.position = Vector2(ox, LANE_Y_OPP)

	var shake: Vector2 = Vector2.ZERO
	if player.wheelspin and player.v > 0.5:
		shake = Vector2(randf_range(-1.5, 1.5), randf_range(-1.5, 1.5))
	if player.nitro_active:
		shake += Vector2(randf_range(-2.0, 2.0), randf_range(-2.0, 2.0))
	cam.position = Vector2(px + 260.0 + shake.x, 360.0 + shake.y)

	smoke.emitting = player.wheelspin and player.v > 0.3 and state != State.DONE
	flame.emitting = player.nitro_active


func _update_hud() -> void:
	hud.rpm = player.rpm
	hud.speed_kmh = player.v * 3.6
	hud.gear = player.gear
	hud.wheelspin = player.wheelspin and player.v > 0.3
	hud.nitro_active = player.nitro_active
	hud.nitro_frac = 0.0 if player.nitro_time <= 0.0 else player.nitro_left / player.nitro_time
	hud.prog_player = player.x / dist
	hud.prog_opp = opp.x / dist
	hud.gap_m = player.x - opp.x if (state == State.RUN and launched) else 0.0
	hud.reaction = reaction
	if state == State.RUN or state == State.DONE:
		if launched and player_t < 0.0:
			hud.clock = race_clock - reaction
		elif player_t > 0.0:
			hud.clock = player_t - reaction
	if state == State.RUN and race_clock > 1.5:
		hud.green = false
		hud.ambers = 0
