extends Node2D
## Highway mode: smooth traffic, collision protection, cargo job and police chase.

const PPM: float = 32.0
const ROAD_TOP: float = 245.0
const ROAD_BOTTOM: float = 655.0
const PLAYER_LEN: float = 6.0
const MAX_SPEED_KMH: float = 250.0
const LANE_COUNT: int = 4
const LANE_HEIGHT: float = 95.0
const PLAYER_START_LANE: int = 2
const CARGO_X: float = 1150.0

var player_x: float = 0.0
var player_speed: float = 0.0
var player_lane: int = PLAYER_START_LANE
var target_lane: int = PLAYER_START_LANE
var player_y: float = 0.0
var collision_cooldown: float = 0.0
var collision_label: Label
var collision_timer: float = 0.0

var cargo_accepted: bool = false
var cargo_delivered: bool = false
var police_active: bool = false
var police_x: float = -20.0
var police_speed: float = 0.0
var arrest_timer: float = 0.0
var arrest_label: Label

var traffic: Array[Dictionary] = []
var traffic_textures: Array[Texture2D] = []
var player_car: Sprite2D
var police_car: Sprite2D
var police_placeholder: bool = false
var police_distance_m: float = 10.0
const TRAFFIC_MIN_GAP_M: float = 9.0
const TRAFFIC_SIDE_CLEAR_M: float = 7.0
var police_path_label: Label
var camera: Camera2D
var lane_input_lock: float = 0.0
var status_label: Label
var cargo_btn: Button
var gas_btn: Button
var brake_btn: Button
var back_btn: Button
var lane_up: Button
var lane_down: Button
var engine_audio: AudioStreamPlayer
var siren_audio: AudioStreamPlayer
var rng := RandomNumberGenerator.new()
var gas_held: bool = false
var brake_held: bool = false

func _ready() -> void:
    rng.randomize()
    player_y = _lane_y(PLAYER_START_LANE)
    _load_traffic_assets()
    _spawn_player()
    _spawn_traffic(18)
    _spawn_police()
    _make_hud()
    _make_audio()
    queue_redraw()
    _update_ui()

func _draw() -> void:
    var left: float = player_x * PPM - 1800.0
    var right: float = player_x * PPM + 3000.0
    draw_rect(Rect2(left, 0.0, right - left, 720.0), Color(0.40, 0.58, 0.72))
    draw_rect(Rect2(left, 160.0, right - left, 80.0), Color(0.24, 0.43, 0.22))
    draw_rect(Rect2(left, ROAD_TOP, right - left, ROAD_BOTTOM - ROAD_TOP), Color(0.12, 0.13, 0.15))
    draw_rect(Rect2(left, ROAD_BOTTOM, right - left, 80.0), Color(0.28, 0.31, 0.34))
    for lane in range(1, LANE_COUNT):
        var y: float = ROAD_TOP + float(lane) * LANE_HEIGHT
        var start: int = int(floor(left / 100.0))
        var end: int = int(ceil(right / 100.0))
        for i in range(start, end + 1):
            draw_rect(Rect2(float(i) * 100.0, y - 3.0, 58.0, 6.0), Color(0.95, 0.95, 0.95, 0.75))
    draw_rect(Rect2(CARGO_X * PPM - 150.0, ROAD_TOP - 62.0, 300.0, 62.0), Color(0.95, 0.65, 0.08))
    draw_string(ThemeDB.fallback_font, Vector2(CARGO_X * PPM - 120.0, ROAD_TOP - 22.0), "CARGO / بار", HORIZONTAL_ALIGNMENT_CENTER, 240.0, 28, Color(0.08, 0.08, 0.08))
    for i in range(-8, 20):
        var x: float = CARGO_X * PPM + float(i) * 120.0
        draw_rect(Rect2(x, 175.0, 72.0, 48.0), Color(0.40, 0.46, 0.52))
        draw_rect(Rect2(x + 12.0, 187.0, 48.0, 30.0), Color(0.66, 0.72, 0.78))

func _load_traffic_assets() -> void:
    traffic_textures.clear()
    # Only use the actual car images. Decorative/shadow variants are excluded.
    var names: Array[String] = ["pars_elx.png", "samand.png", "405.png", "pride.png"]
    for n in names:
        var p: String = "res://assets/" + n
        if ResourceLoader.exists(p):
            var tex: Texture2D = load(p) as Texture2D
            if tex != null:
                traffic_textures.append(tex)

    # Fallback: discover car-looking images if the expected names are missing.
    if traffic_textures.is_empty():
        var dir := DirAccess.open("res://assets")
        if dir == null:
            return
        dir.list_dir_begin()
        while true:
            var f: String = dir.get_next()
            if f == "":
                break
            if dir.current_is_dir():
                continue
            var low: String = f.to_lower()
            if low.contains("police") or low.contains("cop") or low.contains("-sp") or low.contains("-sh"):
                continue
            if low.ends_with(".png") or low.ends_with(".webp") or low.ends_with(".jpg") or low.ends_with(".jpeg"):
                var tex: Texture2D = load("res://assets/" + f) as Texture2D
                if tex != null:
                    traffic_textures.append(tex)
        dir.list_dir_end()

func _spawn_player() -> void:
    player_car = Sprite2D.new()
    var tex: Texture2D = Game.get_car_texture()
    if tex != null:
        player_car.texture = tex
        _fit_sprite(player_car, PLAYER_LEN * PPM)
    player_car.position = Vector2(player_x * PPM, player_y)
    player_car.z_index = 5
    add_child(player_car)

    camera = Camera2D.new()
    camera.position = Vector2(player_x * PPM, player_y)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 8.0
    camera.limit_left = -640
    camera.limit_right = 100000000
    camera.limit_top = 0
    camera.limit_bottom = 720
    camera.enabled = true
    add_child(camera)

func _spawn_traffic(count: int) -> void:
    # Start every traffic car with guaranteed longitudinal and lane separation.
    for i in range(count):
        var lane: int = i % LANE_COUNT
        var x_pos: float = 45.0 + float(i) * 42.0
        _add_traffic_car(x_pos, lane)

func _add_traffic_car(x_pos: float, forced_lane: int = -1) -> void:
    var car := Sprite2D.new()
    if traffic_textures.size() > 0:
        car.texture = traffic_textures[rng.randi_range(0, traffic_textures.size() - 1)]
        _fit_sprite(car, rng.randf_range(4.6, 5.5) * PPM)
    var spawn_lane: int = forced_lane if forced_lane >= 0 else rng.randi_range(0, LANE_COUNT - 1)
    car.position = Vector2(x_pos * PPM, _lane_y(spawn_lane))
    car.z_index = 3
    add_child(car)
    traffic.append({"node": car, "x": x_pos, "speed": rng.randf_range(75.0, 130.0), "lane": spawn_lane, "lane_target": spawn_lane, "change_timer": rng.randf_range(1.5, 5.0)})

func _spawn_police() -> void:
    police_car = Sprite2D.new()
    var path: String = _find_police_asset()
    if path != "":
        police_car.texture = load(path) as Texture2D
        _fit_sprite(police_car, PLAYER_LEN * PPM)
        police_placeholder = false
    else:
        # Temporary visible police marker until the user adds their own image.
        var img := Image.create(110, 110, false, Image.FORMAT_RGBA8)
        img.fill(Color(1.0, 0.48, 0.02, 1.0))
        police_car.texture = ImageTexture.create_from_image(img)
        police_car.scale = Vector2(1.0, 1.0)
        police_placeholder = true
    police_car.position = Vector2((player_x - 10.0) * PPM, player_y)
    police_car.z_index = 10
    police_car.visible = false
    add_child(police_car)

    police_path_label = Label.new()
    police_path_label.text = "عکس پلیس را اینجا بگذار:\nres://assets/police.png"
    police_path_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    police_path_label.add_theme_font_size_override("font_size", 13)
    police_path_label.add_theme_color_override("font_color", Color.WHITE)
    police_path_label.position = Vector2(-170.0, -105.0)
    police_path_label.size = Vector2(340.0, 70.0)
    police_path_label.visible = police_placeholder
    police_car.add_child(police_path_label)

func _find_police_asset() -> String:
    var exact: Array[String] = ["police.png", "police.webp", "police.jpg", "police.jpeg", "police_car.png", "policecar.png", "cop.png", "cop.webp", "police1.png", "police2.png"]
    for n in exact:
        var p: String = "res://assets/" + n
        if ResourceLoader.exists(p):
            return p
    var dir := DirAccess.open("res://assets")
    if dir == null:
        return ""
    dir.list_dir_begin()
    while true:
        var f: String = dir.get_next()
        if f == "":
            break
        if dir.current_is_dir():
            continue
        var low: String = f.to_lower()
        if (low.ends_with(".png") or low.ends_with(".webp") or low.ends_with(".jpg") or low.ends_with(".jpeg")) and (low.contains("police") or low.contains("cop")):
            dir.list_dir_end()
            return "res://assets/" + f
    dir.list_dir_end()
    return ""

func _fit_sprite(s: Sprite2D, width: float) -> void:
    if s.texture == null or s.texture.get_width() <= 0:
        return
    var scale_x: float = width / float(s.texture.get_width())
    s.scale = Vector2(scale_x, scale_x)

func _lane_y(lane: int) -> float:
    return ROAD_TOP + 65.0 + float(lane) * LANE_HEIGHT

func _make_hud() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 20
    add_child(layer)

    var top := ColorRect.new()
    top.color = Color(0.025, 0.035, 0.05, 0.90)
    top.position = Vector2(0, 0)
    top.size = Vector2(1280, 120)
    layer.add_child(top)

    status_label = Label.new()
    status_label.position = Vector2(24, 14)
    status_label.add_theme_font_size_override("font_size", 21)
    status_label.add_theme_color_override("font_color", Color.WHITE)
    status_label.custom_minimum_size = Vector2(850, 94)
    layer.add_child(status_label)

    cargo_btn = _make_button("قبول بار", Vector2(930, 18), Vector2(300, 76), 25)
    cargo_btn.pressed.connect(_accept_cargo)
    layer.add_child(cargo_btn)

    gas_btn = _make_button("گاز  ▲", Vector2(1010, 602), Vector2(230, 95), 28)
    gas_btn.button_down.connect(func(): gas_held = true)
    gas_btn.button_up.connect(func(): gas_held = false)
    layer.add_child(gas_btn)

    brake_btn = _make_button("ترمز", Vector2(760, 602), Vector2(230, 95), 25)
    brake_btn.button_down.connect(func(): brake_held = true)
    brake_btn.button_up.connect(func(): brake_held = false)
    layer.add_child(brake_btn)

    back_btn = _make_button("← گاراژ", Vector2(24, 602), Vector2(190, 95), 23)
    back_btn.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/garage.tscn"))
    layer.add_child(back_btn)

    lane_up = _make_button("▲\nلاین", Vector2(225, 602), Vector2(105, 95), 23)
    lane_up.pressed.connect(func(): target_lane = max(0, target_lane - 1))
    layer.add_child(lane_up)

    lane_down = _make_button("▼\nلاین", Vector2(345, 602), Vector2(105, 95), 23)
    lane_down.pressed.connect(func(): target_lane = min(LANE_COUNT - 1, target_lane + 1))
    layer.add_child(lane_down)

    arrest_label = Label.new()
    arrest_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    arrest_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    arrest_label.position = Vector2(250, 180)
    arrest_label.size = Vector2(780, 90)
    arrest_label.add_theme_font_size_override("font_size", 38)
    arrest_label.add_theme_color_override("font_color", Color(1.0, 0.35, 0.25))
    arrest_label.text = ""
    layer.add_child(arrest_label)

    collision_label = Label.new()
    collision_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    collision_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    collision_label.position = Vector2(315, 270)
    collision_label.size = Vector2(650, 85)
    collision_label.add_theme_font_size_override("font_size", 34)
    collision_label.add_theme_color_override("font_color", Color(1.0, 0.84, 0.25))
    collision_label.text = ""
    layer.add_child(collision_label)

func _make_button(caption: String, pos: Vector2, size: Vector2, font_size: int) -> Button:
    var b := Button.new()
    b.text = caption
    b.position = pos
    b.size = size
    b.add_theme_font_size_override("font_size", font_size)
    b.focus_mode = Control.FOCUS_NONE
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.08, 0.11, 0.16, 0.96)
    normal.corner_radius_top_left = 16
    normal.corner_radius_top_right = 16
    normal.corner_radius_bottom_left = 16
    normal.corner_radius_bottom_right = 16
    normal.border_width_left = 2
    normal.border_width_right = 2
    normal.border_width_top = 2
    normal.border_width_bottom = 2
    normal.border_color = Color(0.32, 0.46, 0.62)
    var hover := normal.duplicate()
    hover.bg_color = Color(0.14, 0.20, 0.28, 0.98)
    var pressed := normal.duplicate()
    pressed.bg_color = Color(0.20, 0.28, 0.38, 1.0)
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", hover)
    b.add_theme_stylebox_override("pressed", pressed)
    return b

func _make_audio() -> void:
    if not Game.sound_on:
        return
    engine_audio = AudioStreamPlayer.new()
    var engine_path: String = _find_audio_asset(["highway_engine", "engine", "car_engine", "motor"])
    if engine_path != "":
        engine_audio.stream = load(engine_path) as AudioStream
    engine_audio.volume_db = -13.0
    engine_audio.autoplay = engine_audio.stream != null
    add_child(engine_audio)

    siren_audio = AudioStreamPlayer.new()
    var siren_path: String = _find_audio_asset(["police_siren", "police", "siren", "cop"])
    if siren_path != "":
        siren_audio.stream = load(siren_path) as AudioStream
    siren_audio.volume_db = -9.0
    siren_audio.autoplay = false
    add_child(siren_audio)

func _find_audio_asset(keywords: Array[String]) -> String:
    var dir := DirAccess.open("res://assets")
    if dir == null:
        return ""
    var fallback: String = ""
    dir.list_dir_begin()
    while true:
        var f: String = dir.get_next()
        if f == "":
            break
        if dir.current_is_dir():
            continue
        var low: String = f.to_lower()
        if not (low.ends_with(".wav") or low.ends_with(".ogg") or low.ends_with(".mp3")):
            continue
        if fallback == "":
            fallback = "res://assets/" + f
        for key in keywords:
            if low.contains(key):
                dir.list_dir_end()
                return "res://assets/" + f
    dir.list_dir_end()
    return fallback if keywords.has("engine") else ""

func _accept_cargo() -> void:
    if cargo_accepted or cargo_delivered:
        return
    if player_x < CARGO_X - 220.0:
        return
    cargo_accepted = true
    police_active = true
    police_x = player_x - police_distance_m
    police_speed = player_speed
    police_car.visible = true
    police_car.position = Vector2(police_x * PPM, player_y)
    police_car.z_index = 10
    if police_path_label != null:
        police_path_label.visible = police_placeholder
    arrest_timer = 0.0
    cargo_btn.disabled = true
    cargo_btn.text = "بار قبول شد!"
    if siren_audio != null and siren_audio.stream != null:
        siren_audio.play()
    _update_ui()

func _process(delta: float) -> void:
    delta = minf(delta, 0.033)
    lane_input_lock = maxf(0.0, lane_input_lock - delta)
    collision_cooldown = maxf(0.0, collision_cooldown - delta)
    collision_timer = maxf(0.0, collision_timer - delta)

    _handle_input(delta)
    _update_player_motion(delta)
    _update_traffic(delta)
    _update_police(delta)
    _check_collisions()
    _check_delivery()
    _update_audio()
    _update_ui()

    if collision_timer <= 0.0 and collision_label != null:
        collision_label.text = ""
    queue_redraw()

func _handle_input(delta: float) -> void:
    var accelerating: bool = gas_held or Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D)
    var braking: bool = brake_held or Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A)
    if accelerating:
        player_speed = minf(MAX_SPEED_KMH, player_speed + 75.0 * delta)
    else:
        player_speed = move_toward(player_speed, 0.0, 12.0 * delta)
    if braking:
        player_speed = move_toward(player_speed, 0.0, 115.0 * delta)
    if Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W):
        target_lane = max(0, target_lane - 1)
    if Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S):
        target_lane = min(LANE_COUNT - 1, target_lane + 1)
    player_speed = clampf(player_speed, 0.0, MAX_SPEED_KMH)

func _update_player_motion(delta: float) -> void:
    var desired_y: float = _lane_y(target_lane)
    var lane_distance: float = desired_y - player_y
    player_y = move_toward(player_y, desired_y, 260.0 * delta)
    if absf(lane_distance) < 3.0:
        player_lane = target_lane
    player_x += player_speed * delta / 3.6
    if player_car != null:
        player_car.position = Vector2(player_x * PPM, player_y)
    if camera != null:
        camera.position = Vector2(player_x * PPM + 120.0, player_y)

func _traffic_gap_safe(x_pos: float, y_pos: float, ignore: Sprite2D, front_gap: float = 18.0, rear_gap: float = 18.0) -> bool:
    for other in traffic:
        var on: Sprite2D = other["node"] as Sprite2D
        if on == ignore:
            continue
        if absf(on.position.y - y_pos) < 58.0:
            var dx: float = float(other["x"]) - x_pos
            if dx > -rear_gap and dx < front_gap:
                return false
    if absf(player_y - y_pos) < 58.0:
        var pdx: float = player_x - x_pos
        if pdx > -rear_gap and pdx < front_gap:
            return false
    if police_active and police_car != null and police_car.visible and absf(police_car.position.y - y_pos) < 58.0:
        var cdx: float = police_x - x_pos
        if cdx > -rear_gap and cdx < front_gap:
            return false
    return true

func _update_traffic(delta: float) -> void:
    # Traffic uses hard longitudinal spacing plus smooth lane changes.
    # A car is never allowed to advance through another car, the player, or police.
    for t in traffic:
        var n: Sprite2D = t["node"] as Sprite2D
        var tx: float = float(t["x"])
        var lane: int = int(t["lane"])
        t["change_timer"] = float(t["change_timer"]) - delta

        if float(t["change_timer"]) <= 0.0:
            var candidates: Array[int] = [lane]
            if lane > 0: candidates.append(lane - 1)
            if lane < LANE_COUNT - 1: candidates.append(lane + 1)
            candidates.shuffle()
            var chosen := lane
            for candidate in candidates:
                if _traffic_gap_safe(tx, _lane_y(candidate), n, TRAFFIC_MIN_GAP_M + 4.0, TRAFFIC_MIN_GAP_M + 4.0):
                    chosen = candidate
                    break
            t["lane_target"] = chosen
            t["change_timer"] = rng.randf_range(2.8, 5.5)

    for t in traffic:
        var n: Sprite2D = t["node"] as Sprite2D
        var tx: float = float(t["x"])
        var lane: int = int(t["lane"])
        var lane_target: int = int(t["lane_target"])
        var target_y: float = _lane_y(lane_target)

        # Do not even start/continue a lane change if the destination has become occupied.
        if lane_target != lane and not _traffic_gap_safe(tx, target_y, n, TRAFFIC_MIN_GAP_M + 5.0, TRAFFIC_MIN_GAP_M + 5.0):
            lane_target = lane
            t["lane_target"] = lane
            target_y = _lane_y(lane)

        n.position.y = move_toward(n.position.y, target_y, 78.0 * delta)
        if absf(n.position.y - target_y) < 2.0:
            n.position.y = target_y
            t["lane"] = lane_target
            lane = lane_target

        var desired_speed: float = float(t["speed"])
        var nearest_gap: float = 1000000000.0
        var nearest_x: float = 1000000000.0

        # Find the nearest obstacle ahead in the current physical lane.
        for other in traffic:
            var on: Sprite2D = other["node"] as Sprite2D
            if on == n:
                continue
            if absf(on.position.y - n.position.y) < TRAFFIC_SIDE_CLEAR_M:
                var gap: float = float(other["x"]) - tx
                if gap > 0.0 and gap < nearest_gap:
                    nearest_gap = gap
                    nearest_x = float(other["x"])

        if absf(player_y - n.position.y) < TRAFFIC_SIDE_CLEAR_M:
            var pgap: float = player_x - tx
            if pgap > 0.0 and pgap < nearest_gap:
                nearest_gap = pgap
                nearest_x = player_x

        if police_active and police_car != null and police_car.visible and absf(police_car.position.y - n.position.y) < TRAFFIC_SIDE_CLEAR_M:
            var cgap: float = police_x - tx
            if cgap > 0.0 and cgap < nearest_gap:
                nearest_gap = cgap
                nearest_x = police_x

        # Progressive braking begins early; below the hard gap the car must stop.
        if nearest_gap < 55.0:
            desired_speed = minf(desired_speed, maxf(0.0, (nearest_gap - TRAFFIC_MIN_GAP_M) * 2.0))
        if nearest_gap < TRAFFIC_MIN_GAP_M:
            desired_speed = 0.0

        # Smooth return to normal traffic speed, never an instant acceleration.
        if nearest_gap >= 55.0:
            desired_speed = move_toward(desired_speed, 92.0, 10.0 * delta)

        desired_speed = clampf(desired_speed, 0.0, 120.0)
        var speed: float = move_toward(float(t["speed"]), desired_speed, 38.0 * delta)
        var advance: float = speed * delta / 3.6

        # Hard positional gate: never cross the minimum longitudinal gap in one frame.
        if nearest_x < 1000000000.0 and nearest_x > tx:
            advance = minf(advance, maxf(0.0, nearest_x - tx - TRAFFIC_MIN_GAP_M))
            if nearest_x - tx <= TRAFFIC_MIN_GAP_M:
                speed = 0.0

        tx += advance
        t["speed"] = speed
        t["x"] = tx
        n.position.x = tx * PPM

        # Respawn only after the car is well behind the camera/player, and put it into a verified safe lane.
        if tx < player_x - 55.0:
            var safe_lanes: Array[int] = []
            for candidate in range(LANE_COUNT):
                if _traffic_gap_safe(player_x + 100.0, _lane_y(candidate), n, 45.0, 35.0):
                    safe_lanes.append(candidate)
            if not safe_lanes.is_empty():
                var safe_lane: int = safe_lanes[rng.randi_range(0, safe_lanes.size() - 1)]
                tx = player_x + rng.randf_range(105.0, 170.0)
                t["x"] = tx
                t["lane"] = safe_lane
                t["lane_target"] = safe_lane
                t["speed"] = rng.randf_range(72.0, 100.0)
                n.position = Vector2(tx * PPM, _lane_y(safe_lane))
                if traffic_textures.size() > 0:
                    n.texture = traffic_textures[rng.randi_range(0, traffic_textures.size() - 1)]
                    _fit_sprite(n, rng.randf_range(5.0, 5.8) * PPM)

func _update_police(delta: float) -> void:
    if not police_active or police_car == null:
        return

    # Police is deliberately locked to a visible position directly behind the player.
    police_x = player_x - police_distance_m
    police_car.position = Vector2(police_x * PPM, player_y)
    police_car.visible = true
    police_car.z_index = 50
    if police_path_label != null:
        police_path_label.visible = police_placeholder
    police_speed = player_speed

    # Reserve the police/player lane so traffic cannot occupy the chase slot.
    for t in traffic:
        var n: Sprite2D = t["node"] as Sprite2D
        if absf(n.position.y - player_y) < TRAFFIC_SIDE_CLEAR_M and absf(float(t["x"]) - police_x) < 18.0:
            var moved := false
            for candidate in range(LANE_COUNT):
                if candidate == int(t["lane"]):
                    continue
                if _traffic_gap_safe(float(t["x"]), _lane_y(candidate), n, TRAFFIC_MIN_GAP_M + 3.0, TRAFFIC_MIN_GAP_M + 3.0):
                    t["lane_target"] = candidate
                    moved = true
                    break
            if not moved:
                t["x"] = player_x + 30.0
                n.position.x = float(t["x"]) * PPM

    # Arrest when police remains essentially bumper-to-bumper for a short time.
    if absf(police_x - player_x) <= 10.5 and absf(police_car.position.y - player_y) < 20.0:
        arrest_timer += delta
        if arrest_timer >= 0.8:
            _arrest_player()
    else:
        arrest_timer = 0.0

func _check_collisions() -> void:
    if collision_cooldown > 0.0:
        return
    for t in traffic:
        var n: Sprite2D = t["node"] as Sprite2D
        var dx: float = absf(float(t["x"]) - player_x)
        var dy: float = absf(n.position.y - player_y)
        if dx < 7.5 and dy < 62.0:
            collision_cooldown = 1.2
            player_speed = minf(player_speed, float(t["speed"]) * 0.55)
            collision_timer = 2.2
            collision_label.text = "شما تصادف کردید!"
            collision_label.modulate = Color(1.0, 0.75, 0.25, 1.0)
            break

func _arrest_player() -> void:
    if not police_active:
        return
    police_active = false
    player_speed = 0.0
    gas_held = false
    brake_held = false
    if siren_audio != null:
        siren_audio.stop()
    if arrest_label != null:
        arrest_label.text = "پلیس شما را دستگیر کرد!"
    if cargo_btn != null:
        cargo_btn.disabled = true
        cargo_btn.text = "دستگیر شدید"
    _update_ui()

func _check_delivery() -> void:
    if cargo_accepted and not cargo_delivered and player_x > CARGO_X + 900.0:
        cargo_delivered = true
        police_active = false
        police_car.visible = false
        if siren_audio != null:
            siren_audio.stop()
        cargo_btn.text = "بار تحویل شد! +$800"
        Game.money += 800
        Game.save_game()

func _update_audio() -> void:
    if engine_audio != null:
        engine_audio.pitch_scale = 0.78 + (player_speed / MAX_SPEED_KMH) * 0.48
        engine_audio.volume_db = -18.0 + (player_speed / MAX_SPEED_KMH) * 7.0
    if siren_audio != null:
        siren_audio.volume_db = -6.0 if police_active else -30.0
        if police_active and siren_audio.stream != null and not siren_audio.playing:
            siren_audio.play()

func _update_ui() -> void:
    if status_label == null:
        return
    var kmh: int = int(round(player_speed))
    var text: String = "بزرگراه  •  سرعت: %d / %d km/h  •  پول: $%d" % [kmh, int(MAX_SPEED_KMH), Game.money]
    if not cargo_accepted:
        text += "\nبه ایستگاه بار برس و «قبول بار» را بزن."
    elif not cargo_delivered:
        text += "\nپلیس پشت سرت است — با کنترل نرم بین لاین‌ها حرکت کن."
    else:
        text += "\nمأموریت تمام شد. $800 دریافت کردی."
    status_label.text = text
    cargo_btn.visible = not cargo_delivered
    cargo_btn.disabled = cargo_accepted or player_x < CARGO_X - 220.0
    if not cargo_accepted:
        cargo_btn.text = "قبول بار" if player_x >= CARGO_X - 220.0 else "رسیدن به ایستگاه بار..."

func _input(_event: InputEvent) -> void:
    pass
